تعليم ال IT — مشروع Android

هذه نسخة مشروع Android وليست موقعًا مطلوبًا فتحه في المتصفح. التطبيق يفتح واجهته محليًا داخل Android WebView، ويتضمن جسر تشغيل Python المدمج عبر Chaquopy.

مهم: لم يتم إنشاء APK جاهز داخل بيئة العمل الحالية لعدم توفر Android SDK وGradle Wrapper JAR. لذلك لا تدّعِ أن ملف APK قد بُني أو اختُبر.

طريقة إنشاء APK على جهازك:
1) فك ضغط هذا المجلد.
2) افتح Android Studio واختر Open ثم اختر مجلد «تعليم-ال-IT-Android».
3) انتظر Gradle Sync. يلزم اتصال إنترنت أول مرة لتنزيل Gradle والاعتمادات ومكوّن Python.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) بعد نجاح البناء اضغط Locate لفتح ملف APK. غالبًا يكون في app/build/outputs/apk/debug/app-debug.apk.
6) اختبر تثبيت التطبيق وتشغيل الدروس والاختبارات وتشغيل Python على هاتف Android قبل الاعتماد عليه.

اسم التطبيق الظاهر على الهاتف: تعليم ال IT
اسم المشروع: تعليم ال IT

لا تحذف AndroidProject/app/src/main/assets/index.html أو ملفات runner.py لأنها مطلوبة لعمل التطبيق.
