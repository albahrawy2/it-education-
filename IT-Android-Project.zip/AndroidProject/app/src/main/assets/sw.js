/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f14f965fad90ac28a1a30368d18cb654"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8f00554cc976375a263010d9f80aae29"
  }, {
    "url": "pwa-192x192.png",
    "revision": "39edd776517a46dce4d639983e7f2e42"
  }, {
    "url": "index.html",
    "revision": "8bf1a61a224d7286017cc75bb53812d8"
  }, {
    "url": "icon.svg",
    "revision": "0fb4369c2d619b32e8fb86317f7ded34"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5c7c0ea255732c5ceb37e0aad3442b1e"
  }, {
    "url": "IT-Android-Studio-Project.zip",
    "revision": "9985f191f6271ef0d9f8481486f5c2f6"
  }, {
    "url": "assets/index-89Z8zzoS.js",
    "revision": null
  }, {
    "url": "assets/index-7FaQLh68.css",
    "revision": null
  }, {
    "url": "assets/IT-Android-Project.zip",
    "revision": null
  }, {
    "url": "assets/aistudio/_____-__-IT-Android-Project_efadba05.zip",
    "revision": null
  }, {
    "url": "assets/aistudio/_D8_AA_D8_B9_D9_84_D9_8A_D9_85_IT__D9_86_D8_B3_D8_AE_D8_A9__D9_85_D8_AD_D8_AF_D8_AB_D8_A9__D9_84_D9_84_D9_85_D8_B3_D8_A7_D8_B9_D8_AF__D9_88_D8_A7_D9_84_D8_A7_D8_AE_D8_AA_D8_A8_D8_A7_D8_B1_D8_A7_D8_AA_5a95ba2d.zip",
    "revision": null
  }, {
    "url": "assets/aistudio/IT-Education-Expanded-Content_7b910e0f.zip",
    "revision": null
  }, {
    "url": "IT-Android-Studio-Project.zip",
    "revision": "9985f191f6271ef0d9f8481486f5c2f6"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5c7c0ea255732c5ceb37e0aad3442b1e"
  }, {
    "url": "icon.svg",
    "revision": "0fb4369c2d619b32e8fb86317f7ded34"
  }, {
    "url": "pwa-192x192.png",
    "revision": "39edd776517a46dce4d639983e7f2e42"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8f00554cc976375a263010d9f80aae29"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f14f965fad90ac28a1a30368d18cb654"
  }, {
    "url": "manifest.webmanifest",
    "revision": "549b6b9b6633c14f31240a44c0fd09cb"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
