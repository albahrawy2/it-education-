import React, { useState, useEffect } from 'react';
import { AppState, Language } from './types';
import { LESSONS } from './data/curriculum';
import { IT_COURSES } from './data/courses';
import { GLOSSARY_TERMS } from './data/glossary';
import { Header } from './components/Header';
import { LessonsView } from './components/LessonsView';
import { PlaygroundView } from './components/PlaygroundView';
import { CoursesView } from './components/CoursesView';
import { GlossaryView } from './components/GlossaryView';
import { AlgorithmVisualizer } from './components/AlgorithmVisualizer';
import { CertificateModal } from './components/CertificateModal';
import { Footer } from './components/Footer';
import { AITutorView } from './components/AITutorView';
import { QuizGeneratorView } from './components/QuizGeneratorView';

const STORAGE_KEY = 'cb_state';

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    const defaultState: AppState = {
      lang: 'ar',
      theme: 'dark',
      currentLesson: 0,
      completedLessons: {},
      quizAnswers: {},
      studentName: 'Mohamed Emad Ali Hassan',
      activeTab: 'lessons',
    };

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...defaultState,
          ...parsed,
          // Support old Android storage structure
          completedLessons: parsed.completedLessons || parsed.done || {},
          quizAnswers: parsed.quizAnswers || parsed.quiz || {},
          currentLesson: typeof parsed.cur === 'number' ? parsed.cur : parsed.currentLesson || 0,
        };
      } catch (e) {
        console.error('Failed to parse saved state:', e);
      }
    }
    return defaultState;
  });

  const [isCertOpen, setIsCertOpen] = useState(false);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Sync theme class to document
  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [state.theme]);

  // Sync lang & dir attributes
  useEffect(() => {
    document.documentElement.lang = state.lang === 'en' ? 'en' : 'ar';
    document.documentElement.dir = state.lang === 'en' ? 'ltr' : 'rtl';
  }, [state.lang]);

  const handleLanguageChange = (lang: Language) => {
    setState((prev) => ({ ...prev, lang }));
  };

  const handleThemeToggle = () => {
    setState((prev) => ({ ...prev, theme: prev.theme === 'dark' ? 'light' : 'dark' }));
  };

  const handleTabChange = (activeTab: AppState['activeTab']) => {
    setState((prev) => ({ ...prev, activeTab }));
  };

  const handleSelectLesson = (idx: number) => {
    setState((prev) => ({ ...prev, currentLesson: idx }));
  };

  const handleLessonComplete = (idx: number) => {
    setState((prev) => ({
      ...prev,
      completedLessons: {
        ...prev.completedLessons,
        [idx]: true,
      },
    }));
  };

  const handleQuizAnswer = (key: string, ansIdx: number) => {
    setState((prev) => ({
      ...prev,
      quizAnswers: {
        ...prev.quizAnswers,
        [key]: ansIdx,
      },
    }));
  };

  const handleUpdateStudentName = (studentName: string) => {
    setState((prev) => ({ ...prev, studentName }));
  };

  const completedCount = Object.keys(state.completedLessons).filter(
    (k) => state.completedLessons[Number(k)]
  ).length;

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors font-sans">
      {/* Sticky Header */}
      <Header
        state={state}
        totalLessons={LESSONS.length}
        completedCount={completedCount}
        onLanguageChange={handleLanguageChange}
        onThemeToggle={handleThemeToggle}
        onTabChange={handleTabChange}
        onOpenCertificate={() => setIsCertOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
        {state.activeTab === 'lessons' && (
          <LessonsView
            lessons={LESSONS}
            state={state}
            onSelectLesson={handleSelectLesson}
            onLessonComplete={handleLessonComplete}
            onQuizAnswer={handleQuizAnswer}
          />
        )}

        {state.activeTab === 'playground' && (
          <PlaygroundView state={state} />
        )}

        {state.activeTab === 'courses' && (
          <CoursesView courses={IT_COURSES} state={state} />
        )}

        {state.activeTab === 'glossary' && (
          <GlossaryView terms={GLOSSARY_TERMS} state={state} />
        )}

        {state.activeTab === 'visualizer' && (
          <AlgorithmVisualizer state={state} />
        )}

        {state.activeTab === 'ai' && <AITutorView state={state} />}

        {state.activeTab === 'quiz' && <QuizGeneratorView state={state} lessons={LESSONS} />}
      </main>

      {/* Certificate Modal */}
      <CertificateModal
        isOpen={isCertOpen}
        onClose={() => setIsCertOpen(false)}
        state={state}
        totalLessons={LESSONS.length}
        completedCount={completedCount}
        onUpdateName={handleUpdateStudentName}
      />

      {/* Footer */}
      <Footer state={state} onTabChange={handleTabChange} />
    </div>
  );
}
