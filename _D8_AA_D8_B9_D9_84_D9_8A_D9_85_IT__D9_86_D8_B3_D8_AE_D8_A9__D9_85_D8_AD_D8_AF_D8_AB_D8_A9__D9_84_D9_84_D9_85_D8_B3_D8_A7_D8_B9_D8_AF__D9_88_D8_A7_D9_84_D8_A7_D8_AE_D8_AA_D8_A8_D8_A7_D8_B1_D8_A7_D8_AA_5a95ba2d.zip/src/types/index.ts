export type Language = 'ar' | 'en' | 'both';

export interface BilingualText {
  ar: string;
  en: string;
}

export interface QuizOption {
  ar: string;
  en: string;
}

export interface QuizQuestion {
  q: BilingualText;
  o: QuizOption[];
  a: number; // Correct option index (0-based)
  explanation?: BilingualText;
}

export interface Challenge {
  task: BilingualText;
  start: string;
  sol: string;
  pyStart: string;
  pySol: string;
  expect: string;
  hint?: BilingualText;
}

export interface Lesson {
  id: number;
  t: BilingualText;
  category: BilingualText;
  p: {
    ar: string[];
    en: string[];
  };
  tips?: BilingualText[];
  ex: string;      // JavaScript example
  py: string;      // Python example
  ch: Challenge;
  qz: QuizQuestion[];
}

export interface ITCourse {
  id: string;
  title: BilingualText;
  category: 'programming' | 'networks' | 'security' | 'systems' | 'skills' | 'hardware' | 'data';
  level: 'beginner' | 'intermediate' | 'advanced';
  description: BilingualText;
  keyTopics: BilingualText[];
  youtubeUrl: string;
  badgeText: BilingualText;
  hoursEst?: number;
}

export interface GlossaryTerm {
  id: string;
  termEn: string;
  termAr: string;
  category: 'programming' | 'networks' | 'security' | 'systems' | 'hardware' | 'data';
  definition: BilingualText;
  example?: BilingualText;
}

export interface RunResult {
  out: string[];
  err: string | null;
  execTimeMs?: number;
  engineUsed?: 'server' | 'client';
}

export interface AppState {
  lang: Language;
  theme: 'light' | 'dark';
  currentLesson: number;
  completedLessons: Record<number, boolean>;
  quizAnswers: Record<string, number>; // key: `${lessonIndex}-${quizIndex}` -> option index
  studentName: string;
  activeTab: 'lessons' | 'playground' | 'courses' | 'glossary' | 'visualizer' | 'ai' | 'quiz';
}
