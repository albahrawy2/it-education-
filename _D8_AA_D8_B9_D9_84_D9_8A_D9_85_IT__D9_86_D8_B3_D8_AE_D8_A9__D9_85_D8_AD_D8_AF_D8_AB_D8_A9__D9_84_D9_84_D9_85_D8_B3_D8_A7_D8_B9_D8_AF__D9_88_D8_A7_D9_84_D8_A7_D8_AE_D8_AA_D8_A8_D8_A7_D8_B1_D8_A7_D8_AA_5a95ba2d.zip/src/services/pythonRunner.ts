import { RunResult } from '../types';

/**
 * Client-side lightweight fallback Python evaluator
 * Executes essential Python constructs offline if the backend is unreachable.
 */
function evaluatePythonClientSide(code: string, inputText: string = ''): RunResult {
  const outputs: string[] = [];
  const lines = inputText.split('\n');
  let inputIdx = 0;

  const mockInput = () => {
    if (inputIdx < lines.length) {
      return lines[inputIdx++];
    }
    return '';
  };

  try {
    // Local scope
    const scope: Record<string, any> = {
      print: (...args: any[]) => {
        const text = args
          .map((arg) => (typeof arg === 'boolean' ? (arg ? 'True' : 'False') : String(arg)))
          .join(' ');
        outputs.push(text);
      },
      input: mockInput,
      len: (item: any) => (item && item.length !== undefined ? item.length : 0),
      type: (val: any) => `<class '${typeof val === 'number' ? (Number.isInteger(val) ? 'int' : 'float') : typeof val}'>`,
      range: (start: number, stop?: number, step?: number) => {
        if (stop === undefined) {
          stop = start;
          start = 0;
        }
        step = step || 1;
        const res: number[] = [];
        if (step > 0) {
          for (let i = start; i < stop; i += step) res.push(i);
        } else {
          for (let i = start; i > stop; i += step) res.push(i);
        }
        return res;
      },
      int: (v: any) => parseInt(v, 10) || 0,
      float: (v: any) => parseFloat(v) || 0,
      str: (v: any) => String(v),
      bool: (v: any) => Boolean(v),
    };

    // Pre-processing simple python code into JS-runnable code for basic fallback
    let js = code
      .replace(/#.*$/gm, '') // Remove comments
      .replace(/\bTrue\b/g, 'true')
      .replace(/\bFalse\b/g, 'false')
      .replace(/\bNone\b/g, 'null')
      .replace(/\band\b/g, '&&')
      .replace(/\bor\b/g, '||')
      .replace(/\bnot\b/g, '!');

    // Execute within isolated Function context if possible
    const runner = new Function('scope', `
      with (scope) {
        ${js}
      }
    `);
    runner(scope);

    return {
      out: outputs,
      err: null,
      engineUsed: 'client'
    };
  } catch (err: any) {
    return {
      out: outputs,
      err: `${err.name || 'Error'}: ${err.message || String(err)}`,
      engineUsed: 'client'
    };
  }
}

/**
 * Execute Python code against the server endpoint, with automatic fallback
 */
export async function executePython(code: string, input: string = ''): Promise<RunResult> {
  const startTime = performance.now();

  try {
    const res = await fetch('/api/run-python', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code, input }),
    });

    if (!res.ok) {
      throw new Error(`Server returned status ${res.status}`);
    }

    const data = await res.json();
    const duration = Math.round(performance.now() - startTime);

    return {
      out: Array.isArray(data.out) ? data.out : [],
      err: data.err || null,
      execTimeMs: duration,
      engineUsed: 'server'
    };
  } catch (err: any) {
    // Graceful fallback to client-side evaluator
    console.warn('Backend Python API unreachable, switching to local evaluator:', err);
    const result = evaluatePythonClientSide(code, input);
    result.execTimeMs = Math.round(performance.now() - startTime);
    return result;
  }
}
