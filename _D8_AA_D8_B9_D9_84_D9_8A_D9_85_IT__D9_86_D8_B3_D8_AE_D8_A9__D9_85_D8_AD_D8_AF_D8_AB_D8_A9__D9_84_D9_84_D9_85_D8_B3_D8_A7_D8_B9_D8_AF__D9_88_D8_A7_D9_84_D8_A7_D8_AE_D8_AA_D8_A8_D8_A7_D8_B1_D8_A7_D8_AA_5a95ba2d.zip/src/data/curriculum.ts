import { Lesson } from '../types';

export const LESSONS: Lesson[] = [
  {
    id: 1,
    t: { ar: 'ما هي البرمجة؟ والخوارزميات', en: 'What is Programming & Algorithms?' },
    category: { ar: 'المفاهيم التأسيسية', en: 'Foundations' },
    p: {
      ar: [
        'البرمجة هي كتابة تعليمات دقيقة ومرتبة ليفهمها الحاسوب وينفّذها. الحاسوب سريع جدًا لكنه لا يفكّر بمفرده، فهو ينفّذ ما تكتبه حرفيًا وبلا تردد.',
        'قبل كتابة أي سطر كود، نفكّر في <b>الخوارزمية (Algorithm)</b>: وهي سلسلة خطوات منطقية ومرتبة بدقة لحل مشكلة أو إنجاز مهمة محددة. مثال بسيط: خوارزمية إعداد الشاي (سخّن الماء ← ضع الشاي ← انتظر دقيقتين ← أضف السكر وحرّك).',
        'نعبّر عن الخوارزمية باستخدام لغة برمجة عالية المستوى مثل <b>Python</b>. الأفكار البرمجية الأساسية موحدة بين جميع اللغات، وتعلّم بايثون يمنحك أساسًا صلبًا لكل مجالات تكنولوجيا المعلومات.',
        'الأمر <code>print()</code> هو أداة التخاطب الأساسية في بايثون لعرض النصوص والنتائج الحسابية على الشاشة أو وحدة التحكم (Terminal).'
      ],
      en: [
        'Programming means writing precise, ordered instructions that a computer can follow. A computer is extremely fast but it does not think; it does exactly what you write without hesitation.',
        'Before writing any code, we think about the <b>algorithm</b>: a sequence of clear, ordered steps that solve a problem. Example: making tea (heat water → add tea leaves → steep for 2 minutes → add sugar and stir).',
        'We express algorithms using high-level programming languages such as <b>Python</b>. The core programming concepts are universal across languages, and learning Python gives you a rock-solid foundation for all IT domains.',
        'The command <code>print()</code> is the primary way in Python to output text and arithmetic results to the console.'
      ]
    },
    tips: [
      { ar: 'النصوص في بايثون توضع دائمًا داخل علامات تنصيص مفردة \' \' أو مزدوجة " "، بينما الأرقام والعمليات الحسابية تكتب بدون علامات تنصيص.', en: 'Strings in Python are always placed inside quotes (\' \' or " "), while numbers and math expressions are written without quotes.' },
      { ar: 'يمكنك طباعة عدة عناصر في نفس أمر print بالفصل بينها بفاصلة: print("النتيجة:", 10 + 5)', en: 'You can print multiple items in a single print call by separating them with commas: print("Result:", 10 + 5)' }
    ],
    ex: `console.log("Hello, ICT!");\nconsole.log("My first program");`,
    py: `# مثالك الأول في بايثون\nprint("Hello, ICT!")\nprint("My first program")\nprint("النتيجة الحسابية:", 20 + 26)`,
    ch: {
      task: {
        ar: 'اطبع الجملة التالية بالضبط باستخدام بايثون: <code>Hello, World!</code>',
        en: 'Print exactly the following sentence using Python: <code>Hello, World!</code>'
      },
      start: `// write your code here\n`,
      sol: `console.log("Hello, World!");`,
      pyStart: `# اكتب كود الحل هنا\n`,
      pySol: `print("Hello, World!")`,
      expect: 'Hello, World!',
      hint: {
        ar: 'استخدم الدالة print وضع النص بين علامتي تنصيص مزدوجتين كما هو تمامًا.',
        en: 'Use the print function and place the string in double quotes exactly as written.'
      }
    },
    qz: [
      {
        q: { ar: 'ما هو التعريف الدقيق للخوارزمية (Algorithm)؟', en: 'What is the precise definition of an Algorithm?' },
        o: [
          { ar: 'لغة برمجة مثل بايثون أو جافا', en: 'A programming language like Python or Java' },
          { ar: 'مجموعة خطوات منطقية مرتبة بدقة لحل مشكلة ما', en: 'A set of precise, ordered logical steps to solve a problem' },
          { ar: 'قطعة إلكترونية مادية داخل المعالج', en: 'A physical hardware part inside the CPU' },
          { ar: 'برنامج مخصص لتصميم الرسوميات', en: 'A program dedicated to graphics design' }
        ],
        a: 1,
        explanation: {
          ar: 'الخوارزمية هي المخطط المنطقي والخطوات المرتبة لحل المسألة قبل تحويلها إلى كود برمجي.',
          en: 'An algorithm is the logical blueprint and ordered steps to solve a problem before turning it into code.'
        }
      },
      {
        q: { ar: 'أي دالة نستخدمها في لغة بايثون لطباعة المخرجات على الشاشة؟', en: 'Which function is used in Python to display output on screen?' },
        o: [
          { ar: 'print()', en: 'print()' },
          { ar: 'input()', en: 'input()' },
          { ar: 'output()', en: 'output()' },
          { ar: 'echo()', en: 'echo()' }
        ],
        a: 0,
        explanation: {
          ar: 'print() هي الدالة القياسية في بايثون لإخراج النصوص والقيم إلى سطر الأوامر.',
          en: 'print() is the standard built-in Python function to write text and values to stdout.'
        }
      }
    ]
  },
  {
    id: 2,
    t: { ar: 'المتغيرات والثوابت', en: 'Variables and Constants' },
    category: { ar: 'إدارة البيانات', en: 'Data Management' },
    p: {
      ar: [
        'المتغير (Variable) هو مساحة محجوزة في ذاكرة الحاسوب (RAM) لها اسم محدد، تُستخدم لتخزين قيمة واسترجاعها أو تعديلها لاحقًا أثناء تشغيل البرنامج.',
        'في بايثون، لا نحتاج لتحديد نوع المتغير يدويًا؛ فبايثون لغة ديناميكية تكتشف النوع تلقائيًا بمجرد إسناد القيمة: مثل <code>age = 20</code> أو <code>name = "Ali"</code>.',
        'قواعد تسمية المتغيرات: يجب أن يبدأ الاسم بحرف أو شرطة سفلية <code>_</code>، ولا يحتوي على مسافات أو رموز خاصة، والحروف الكبيرة تختلف عن الصغيرة (<code>age</code> تختلف عن <code>Age</code>). يفضل اتباع أسلوب <code>snake_case</code>.',
        'علامة <code>=</code> في البرمجة هي عامل إسناد (Assignment Operator) وليس مساواة رياضية. فالسطر <code>x = x + 1</code> يعني: احسب قيمة x الحالية وأضف إليها 1 ثم احفظ الناتج من جديد في x.'
      ],
      en: [
        'A variable is a reserved storage space in computer memory (RAM) with an assigned name, used to store, retrieve, or modify a value while a program runs.',
        'In Python, you do not declare variable types explicitly; Python is dynamically typed and infers the type automatically upon assignment, such as <code>age = 20</code> or <code>name = "Ali"</code>.',
        'Naming rules: must begin with a letter or underscore <code>_</code>, cannot contain spaces or special symbols, and names are case-sensitive (<code>age</code> is distinct from <code>Age</code>). The convention in Python is <code>snake_case</code>.',
        'The <code>=</code> sign in programming is an assignment operator, not a mathematical equivalence. The statement <code>x = x + 1</code> means: evaluate x + 1, then store the result back into x.'
      ]
    },
    tips: [
      { ar: 'لتعريف ثابت في بايثون، جرى العرف بين المبرمجين على كتابة اسمه بأحرف كبيرة بالكامل مثل MAX_LIMIT أو PI للتنبيه بعدم تغييره.', en: 'By convention in Python, constants are named in ALL_CAPS such as PI or MAX_LIMIT to indicate that their value should not be modified.' },
      { ar: 'يمكنك إسناد أكثر من متغير في سطر واحد: x, y = 10, 20', en: 'You can assign multiple variables in one line: x, y = 10, 20' }
    ],
    ex: `let name = "Sara";\nlet age = 20;\nconst PI = 3.14;\nage = age + 1;\nconsole.log(name, age, PI);`,
    py: `# تعريف المتغيرات والثوابت\nname = "Sara"\nage = 20\nPI = 3.14           # ثابت اصطلاحي\nage = age + 1       # زيادة العمر بسنة\n\nprint("الاسم:", name)\nprint("العمر:", age)\nprint("قيمة PI:", PI)`,
    ch: {
      task: {
        ar: 'احسب واطبع السعر الإجمالي للمنتجات بضرب السعر في الكمية باستخدام المتغيرين المعرفين.',
        en: 'Calculate and print the total price (price × qty) using the two predefined variables.'
      },
      start: `let price = 100;\nlet qty = 3;\n// print the total\n`,
      sol: `let price = 100;\nlet qty = 3;\nconsole.log(price * qty);`,
      pyStart: `price = 100\nqty = 3\n# احسب واطبع الإجمالي هنا\n`,
      pySol: `price = 100\nqty = 3\nprint(price * qty)`,
      expect: '300',
      hint: {
        ar: 'استخدم علامة الضرب * بين المتغيرين داخل دالة print().',
        en: 'Use the multiplication operator * between price and qty inside print().'
      }
    },
    qz: [
      {
        q: { ar: 'أي من أسماء المتغيرات التالية يعتبر اسمًا صحيحًا ومقبولًا في بايثون؟', en: 'Which of the following is a valid variable name in Python?' },
        o: [
          { ar: '2user_name (يبدأ برقم)', en: '2user_name (starts with digit)' },
          { ar: 'user name (يحتوي مسافة)', en: 'user name (contains space)' },
          { ar: 'user_name (أحرف وشرطة سفلية)', en: 'user_name (letters and underscore)' },
          { ar: 'user-name (يحتوي علامة طرح)', en: 'user-name (contains hyphen)' }
        ],
        a: 2,
        explanation: {
          ar: 'الاسم user_name يبدأ بحرف ويحتوي شرطة سفلية مسموح بها ولا يحوي مسافات أو رموز ممنوعة.',
          en: 'user_name starts with a letter, uses valid underscores, and avoids spaces and reserved operators.'
        }
      },
      {
        q: { ar: 'كيف يتفق المبرمجون في بايثون على تمييز المتغير الثابت (Constant)؟', en: 'How do Python developers conventionally designate constants?' },
        o: [
          { ar: 'باستخدام أحرف كبيرة كاملة مثل MAX_USERS', en: 'Using all-uppercase letters such as MAX_USERS' },
          { ar: 'باستخدام الكلمة المفتاحية const', en: 'Using the const keyword' },
          { ar: 'بوضع علامة # قبل الاسم', en: 'By prefixing the name with #' },
          { ar: 'لا توجد طريقة لتمييز الثوابت', en: 'There is no way to denote constants' }
        ],
        a: 0,
        explanation: {
          ar: 'بايثون لا تحتوي كلمة const، لذا يعتمد المبرمجون تسمية الثوابت بأحرف كبيرة UPPER_CASE.',
          en: 'Python has no const keyword; developers follow the PEP 8 convention of ALL_CAPS naming.'
        }
      }
    ]
  },
  {
    id: 3,
    t: { ar: 'أنواع البيانات والعمليات', en: 'Data Types & Operators' },
    category: { ar: 'أنواع البيانات', en: 'Data Types' },
    p: {
      ar: [
        'لكل قيمة في البرنامج <b>نوع (Data Type)</b> يحدد العمليات الممكن إجراؤها عليها. الأنواع الأساسية في بايثون هي: <code>int</code> للأعداد الصحيحة (مثل 42)، و<code>float</code> للأعداد العشرية (مثل 3.14)، و<code>str</code> للنصوص (مثل "Ali")، و<code>bool</code> للقيم المنطقية (True أو False).',
        'العمليات الحسابية: الجمع <code>+</code>، الطرح <code>-</code>، الضرب <code>*</code>، القسمة <code>/</code>، القسمة الصحيحة <code>//</code>، وباقي القسمة (Modulo) <code>%</code>، والأس <code>**</code>.',
        'عملية باقي القسمة <code>%</code> مهمة جدًا لاختبار قابلية القسمة والزوجي والفردي: فمثلاً <code>17 % 5</code> يساوي 2 لأن 17 = (5 × 3) + 2.',
        'عمليات المقارنة تُرجع دائماً قيمة منطقية (True أو False): <code>&gt;, &lt;, &gt;=, &lt;=, ==, !=</code>. انتبه: <code>==</code> للاختبار بالمساواة، بينما <code>!=</code> تعني لا يساوي.'
      ],
      en: [
        'Every value in a program has a <b>data type</b> that determines what operations can be performed on it. Python core types include: <code>int</code> for integers (e.g. 42), <code>float</code> for decimals (e.g. 3.14), <code>str</code> for strings (e.g. "Ali"), and <code>bool</code> for booleans (True or False).',
        'Arithmetic operators include: addition <code>+</code>, subtraction <code>-</code>, multiplication <code>*</code>, division <code>/</code>, floor division <code>//</code>, modulo <code>%</code>, and exponentiation <code>**</code>.',
        'The modulo operator <code>%</code> yields the remainder of division; e.g. <code>17 % 5</code> equals 2 because 17 = (5 × 3) + 2. It is widely used to check parity (even/odd).',
        'Comparison operators always evaluate to a boolean (True or False): <code>&gt;, &lt;, &gt;=, &lt;=, ==, !=</code>. Note: <code>==</code> tests equality, whereas <code>!=</code> tests inequality.'
      ]
    },
    tips: [
      { ar: 'لمعرفة نوع أي متغير في بايثون، استخدم دالة type(variable)، مثل type(3.14) تعطي float.', en: 'To inspect any variable type in Python, use the type() function, e.g. type(3.14) yields float.' },
      { ar: 'التحويل بين الأنواع (Type Casting) يتم عبر: int(), float(), str(), bool().', en: 'Type conversion is done using built-in constructors: int(), float(), str(), bool().' }
    ],
    ex: `console.log(7 + 3);          // 10\nconsole.log(17 % 5);         // 2\nconsole.log("Hi " + "ICT");  // Hi ICT\nconsole.log(5 > 3);          // true\nconsole.log(typeof "text");  // string`,
    py: `# تجربة العمليات وأنواع البيانات\nprint("الجمع:", 7 + 3)\nprint("باقي القسمة 17 % 5:", 17 % 5)\nprint("دمج النصوص:", "مرحبًا " + "IT")\nprint("مقارنة (هل 5 أكبر من 3؟):", 5 > 3)\nprint("نوع القيمة:", type("نص"))\nprint("الأس 2 أس 4:", 2 ** 4)`,
    ch: {
      task: {
        ar: 'احسب واطبع باقي قسمة العدد 29 على 6.',
        en: 'Calculate and print the remainder of 29 divided by 6.'
      },
      start: `// print the remainder of 29 / 6\n`,
      sol: `console.log(29 % 6);`,
      pyStart: `# اطبع باقي قسمة 29 على 6\n`,
      pySol: `print(29 % 6)`,
      expect: '5',
      hint: {
        ar: 'استخدم معامل باقي القسمة %: 29 % 6 = 5 لأن 6 × 4 = 24 والباقي 5.',
        en: 'Use the modulo operator %: 29 % 6 equals 5 because 6 * 4 = 24 with a remainder of 5.'
      }
    },
    qz: [
      {
        q: { ar: 'ما هو الناتج الحسابي للعملية: 10 % 3 ؟', en: 'What is the arithmetic result of: 10 % 3?' },
        o: [
          { ar: '3', en: '3' },
          { ar: '1 (الباقي بعد 3 × 3 = 9)', en: '1 (the remainder after 3 * 3 = 9)' },
          { ar: '0', en: '0' },
          { ar: '3.333', en: '3.333' }
        ],
        a: 1,
        explanation: {
          ar: '10 تقسيم 3 يعطي 3 ويبقى 1، لذا ناتج 10 % 3 هو 1.',
          en: '10 divided by 3 is 3 with remainder 1, hence 10 % 3 returns 1.'
        }
      },
      {
        q: { ar: 'ما هو نوع القيمة True في لغة بايثون؟', en: 'What is the data type of the value True in Python?' },
        o: [
          { ar: 'int (عدد صحيح)', en: 'int (integer)' },
          { ar: 'str (نص)', en: 'str (string)' },
          { ar: 'bool (قيمة منطقية بولية)', en: 'bool (boolean value)' },
          { ar: 'list (قائمة)', en: 'list (array)' }
        ],
        a: 2,
        explanation: {
          ar: 'True و False هما القيمتان الوحيدتان لنوع البيانات المنطقي bool.',
          en: 'True and False are the two canonical values of the boolean (bool) type.'
        }
      }
    ]
  },
  {
    id: 4,
    t: { ar: 'الشروط واتخاذ القرار (if / elif / else)', en: 'Decisions & Conditions (if / elif / else)' },
    category: { ar: 'التحكم في التدفق', en: 'Control Flow' },
    p: {
      ar: [
        'الجمل الشرطية تمنح البرنامج القدرة على التفكير واتخاذ قرارات ذكية: تنفيذ جزء من الكود فقط عندما يتحقق شرط معين.',
        'الصيغة الأساسية في بايثون: <code>if الشرط:</code> يليها سطر مزاح إلى الداخل (Indentation)، ويمكن استخدام <code>elif</code> لاختبار شروط إضافية، و<code>else</code> كخيار افتراضي في حال عدم تحقق أي من الشروط.',
        'المسافة البادئة (Indentation) في بايثون ليست مجرد تنسيق جمالي، بل هي جزء أساسي من بنية اللغة وتحدد حدود البلوك البرمجي التابع للشرط.',
        'الروابط المنطقية: <code>and</code> (يجب تحقق كلا الشرطين معًا)، <code>or</code> (يكفي تحقق أحدهما)، <code>not</code> (نفي الشرط).'
      ],
      en: [
        'Conditional statements empower programs to make logical decisions: executing specific blocks of code only when criteria are met.',
        'The core syntax in Python: <code>if condition:</code> followed by an indented block, with optional <code>elif condition:</code> branches, and an <code>else:</code> fallback when no prior conditions hold.',
        'Indentation in Python is not mere styling; it is syntactically required to delineate the body of control structures.',
        'Logical operators: <code>and</code> (both conditions must be True), <code>or</code> (at least one must be True), and <code>not</code> (inverts the boolean value).'
      ]
    },
    tips: [
      { ar: 'المسافة البادئة المعتمدة في بايثون هي 4 مسافات أو زر Tab واحد. حافظ على اتساق المسافات لتجنب خطأ IndentationError.', en: 'Standard indentation in Python is 4 spaces. Maintain consistent indentation to avoid IndentationError.' },
      { ar: 'يمكن كتابة الشرط المختصر (Ternary Operator): status = "ناجح" if grade >= 50 else "راسب"', en: 'You can write one-line ternary expressions: status = "Pass" if grade >= 50 else "Fail"' }
    ],
    ex: `let temp = 35;\nif (temp > 30) {\n  console.log("Hot");\n} else if (temp > 20) {\n  console.log("Nice");\n} else {\n  console.log("Cold");\n}`,
    py: `# نظام تقييم حالة الطقس\ntemp = 35\n\nif temp > 30:\n    print("الطقس حار (Hot)")\nelif temp > 20:\n    print("الطقس معتدل (Nice)")\nelse:\n    print("الطقس بارد (Cold)")`,
    ch: {
      task: {
        ar: 'لديك المتغير <code>grade = 72</code>. اكتب شرطًا يطبع <code>Pass</code> إذا كانت الدرجة 50 أو أكثر، وإلا يطبع <code>Fail</code>.',
        en: 'Given <code>grade = 72</code>, write a condition that prints <code>Pass</code> if grade is 50 or above, otherwise prints <code>Fail</code>.'
      },
      start: `let grade = 72;\nif (grade >= 50) {\n  console.log("Pass");\n} else {\n  console.log("Fail");\n}`,
      sol: `let grade = 72;\nif (grade >= 50) {\n  console.log("Pass");\n} else {\n  console.log("Fail");\n}`,
      pyStart: `grade = 72\n# اكتب شرط النجاح أو الرسوب هنا\n`,
      pySol: `grade = 72\nif grade >= 50:\n    print("Pass")\nelse:\n    print("Fail")`,
      expect: 'Pass',
      hint: {
        ar: 'استخدم if grade >= 50: ثم print("Pass") ثم else: ثم print("Fail"). تأكد من المسافات البادئة.',
        en: 'Use if grade >= 50: print("Pass") followed by else: print("Fail"). Ensure proper indentation.'
      }
    },
    qz: [
      {
        q: { ar: 'إذا كانت قيمة x = 5، فماذا ستطبع الشيفرة: if x > 5: print("A") else: print("B")؟', en: 'If x = 5, what will the code print: if x > 5: print("A") else: print("B")?' },
        o: [
          { ar: 'A', en: 'A' },
          { ar: 'B (لأن 5 ليست أكبر قطعا من 5)', en: 'B (because 5 is not strictly greater than 5)' },
          { ar: 'A ثم B', en: 'A then B' },
          { ar: 'يحدث خطأ برمجي', en: 'A syntax error occurs' }
        ],
        a: 1,
        explanation: {
          ar: 'الشرط 5 > 5 نتيجته False لأن 5 تساوي 5 وليست أكبر، لذا ينتقل التنفيذ إلى قسم else ويطبع B.',
          en: '5 > 5 evaluates to False because 5 is equal to 5, not greater, so execution branches to else, printing B.'
        }
      },
      {
        q: { ar: 'أي كلمة مفتاحية نستخدمها لاختبار شرط بديل في حال لم يتحقق الشرط الأول في بايثون؟', en: 'Which keyword in Python tests an alternative condition if the first condition is false?' },
        o: [
          { ar: 'else if', en: 'else if' },
          { ar: 'elif', en: 'elif' },
          { ar: 'elseif', en: 'elseif' },
          { ar: 'then', en: 'then' }
        ],
        a: 1,
        explanation: {
          ar: 'بايثون تختصر عبارتَي else if في الكلمة المفتاحية الواحدة: elif.',
          en: 'Python combines else if into the single concise keyword: elif.'
        }
      }
    ]
  },
  {
    id: 5,
    t: { ar: 'التكرار والحلقات (for & while)', en: 'Repetition & Loops (for & while)' },
    category: { ar: 'التحكم في التدفق', en: 'Control Flow' },
    p: {
      ar: [
        'الحلقات (Loops) تمكّنك من تكرار تنفيذ كتلة برمجية معينة عدة مرات آلياً دون الحاجة لكتابتها يدوياً مئات المرات.',
        'حلقة <code>for</code> مع دالة <code>range()</code> تُستخدم عندما تكون على علم مسبق بعدد مرات التكرار. الدالة <code>range(1, 6)</code> تولّد الأعداد من 1 إلى 5 (الرقم النهائي 6 غير مشمول).',
        'حلقة <code>while</code> تستمر في التكرار طالما كان شرطها صحيحاً (True). تحذير: إذا لم يتم تحديث المتغير ليصبح الشرط خاطئاً في نقطة ما، ستدخل الحلقة في تكرار لا نهائي (Infinite Loop) يجمّد البرنامج.',
        'العبارات <code>break</code> لإيقاف الحلقة والخروج منها فوراً، و<code>continue</code> لتخطي التكرار الحالي والانتقال للدورة التالية.'
      ],
      en: [
        'Loops enable programs to execute a code block repeatedly without duplicating lines of code.',
        'The <code>for</code> loop combined with <code>range()</code> is ideal when the iteration count is known in advance. Note that <code>range(1, 6)</code> generates values 1 through 5 (the stop bound is exclusive).',
        'The <code>while</code> loop continues looping as long as its boolean condition remains True. Warning: if the condition never becomes False, the loop runs infinitely, locking the execution environment.',
        'Control statements: <code>break</code> terminates loop execution immediately, and <code>continue</code> skips the remainder of the current iteration.'
      ]
    },
    tips: [
      { ar: 'الدالة range(stop) تبدأ من 0، بينما range(start, stop, step) تتيح تحديد نقطة البداية والخطوة مثل range(0, 10, 2) للأعداد الزوجية.', en: 'range(stop) starts at 0; range(start, stop, step) allows custom increments, such as range(0, 10, 2) for even numbers.' },
      { ar: 'احرص دائماً داخل حلقة while على وجود سطر يعدل الشرط، مثل count += 1.', en: 'Always ensure your while loop has a progression statement, such as count += 1, to guarantee termination.' }
    ],
    ex: `for (let i = 1; i <= 5; i++) {\n  console.log("Number " + i);\n}\n\nlet n = 3;\nwhile (n > 0) {\n  console.log(n);\n  n--;\n}`,
    py: `# التكرار باستخدام for و while\nprint("--- تجربة حلقة for ---")\nfor i in range(1, 6):\n    print("العدد:", i)\n\nprint("--- تجربة حلقة while ---")\ncountdown = 3\nwhile countdown > 0:\n    print("العد التنازلي:", countdown)\n    countdown -= 1\nprint("انطلاق!")`,
    ch: {
      task: {
        ar: 'احسب مجموع الأعداد من 1 إلى 10 (1+2+3+...+10) باستخدام حلقة تكرار، ثم اطبع المجموع النهائي.',
        en: 'Compute the sum of numbers from 1 to 10 (1+2+3+...+10) using a loop, then print the total.'
      },
      start: `let sum = 0;\nfor (let i = 1; i <= 10; i++) {\n  sum += i;\n}\nconsole.log(sum);`,
      sol: `let sum = 0;\nfor (let i = 1; i <= 10; i++) {\n  sum += i;\n}\nconsole.log(sum);`,
      pyStart: `total = 0\n# اجمع الأرقام من 1 إلى 10 باستخدام حلقة\nprint(total)`,
      pySol: `total = 0\nfor i in range(1, 11):\n    total += i\nprint(total)`,
      expect: '55',
      hint: {
        ar: 'تذكر أن range(1, 11) تشمل الأرقام من 1 حتى 10. بداخل الحلقة اكتب total += i.',
        en: 'Remember range(1, 11) covers integers from 1 up to 10. Inside the loop, accumulate with total += i.'
      }
    },
    qz: [
      {
        q: { ar: 'كم عدد المرات التي ستتكرر فيها حلقة الكود: for i in range(4): ؟', en: 'How many times will this loop execute: for i in range(4):?' },
        o: [
          { ar: '3 مرات', en: '3 times' },
          { ar: '4 مرات (للأرقام 0، 1، 2، 3)', en: '4 times (for values 0, 1, 2, 3)' },
          { ar: '5 مرات', en: '5 times' },
          { ar: 'مرة واحدة فقط', en: 'Once only' }
        ],
        a: 1,
        explanation: {
          ar: 'range(4) تبدأ من 0 حتى 3، ومجموع هذه التكرارات 4 مرات.',
          en: 'range(4) yields 0, 1, 2, 3, which executes exactly 4 iterations.'
        }
      },
      {
        q: { ar: 'ما الخطر الأكبر عند كتابة حلقة while إذا نسي المبرمج تحديث متغير الشرط؟', en: 'What is the primary danger when writing a while loop without updating its condition variable?' },
        o: [
          { ar: 'يتوقف المعالج عن العمل نهائياً', en: 'The hardware burns out' },
          { ar: 'حدوث حلقة لا نهائية (Infinite Loop) وتجمّد البرنامج', en: 'An infinite loop is created, hanging the application' },
          { ar: 'تتحول الحلقة تلقائياً إلى جملة if', en: 'The loop automatically becomes an if' },
          { ar: 'لا يحدث أي ضرر ويتجاهلها المفسر', en: 'Nothing happens; Python ignores it' }
        ],
        a: 1,
        explanation: {
          ar: 'إذا ظل الشرط True دائماً، فإن الحلقة ستستمر للأبد وتستهلك موارد النظام حتى إيقافها بالقوة.',
          en: 'If the condition stays permanently True, execution loops endlessly, consuming resources until halted.'
        }
      }
    ]
  },
  {
    id: 6,
    t: { ar: 'الدوال والمعاملات (Functions)', en: 'Functions & Parameters' },
    category: { ar: 'تنظيم الشيفرة', en: 'Code Architecture' },
    p: {
      ar: [
        'الدالة (Function) هي كتلة برمجية مستقلة تحمل اسماً محدداً، نكتبها مرة واحدة ونستدعيها عند الحاجة في أي مكان داخل البرنامج، مما يمنع تكرار الكود (مبدأ DRY: Don\'t Repeat Yourself).',
        'تستقبل الدالة مدخلات تسمى <b>معاملات (Parameters)</b>، وتُرجع النتيجة للمستدعي باستخدام الكلمة المفتاحية <code>return</code>.',
        'تعريف الدالة في بايثون يبدأ بالكلمة <code>def</code> يليها اسم الدالة والأقواس: <code>def calculate_area(w, h):</code>.',
        'أمر <code>return</code> ينهي عمل الدالة فوراً ويعيد القيمة المحسوبة إلى السطر الذي استدعاها.'
      ],
      en: [
        'A function is a reusable, self-contained block of code designed to perform a specific task, upholding the DRY (Don\'t Repeat Yourself) principle.',
        'Functions accept inputs called <b>parameters (arguments)</b>, process data, and return computed results using the <code>return</code> keyword.',
        'Function declaration in Python begins with <code>def</code> followed by the function name and parameter list: <code>def calculate_area(w, h):</code>.',
        'The <code>return</code> statement immediately terminates function execution and yields the resulting value back to the caller.'
      ]
    },
    tips: [
      { ar: 'يمكنك إعطاء قيم افتراضية للمعاملات: def greet(name="طالب"): print("أهلاً", name)', en: 'You can define default parameter values: def greet(name="Student"): print("Hello", name)' },
      { ar: 'الدالة التي لا تحتوي أمر return تُرجع القيمة الخاصة None ضمنياً.', en: 'A function that omits a return statement implicitly returns None.' }
    ],
    ex: `function greet(name) {\n  return "Hello " + name;\n}\n\nconsole.log(greet("Omar"));\nconsole.log(greet("Salma"));`,
    py: `# تعريف دوال الترحيب والحساب\ndef greet(name):\n    return f"مرحبًا بك في IT يا {name}!"\n\ndef add(a, b):\n    return a + b\n\nprint(greet("عمر"))\nprint(greet("سلمى"))\nprint("حاصل جمع 15 + 25 =", add(15, 25))`,
    ch: {
      task: {
        ar: 'أكمل الدالة <code>square(n)</code> لتُرجع مربع العدد (العدد مضروباً في نفسه). عند استدعاء <code>square(7)</code> يجب أن يُطبع الناتج <code>49</code>.',
        en: 'Complete the function <code>square(n)</code> to return the square of a number (n * n). Calling <code>square(7)</code> must print <code>49</code>.'
      },
      start: `function square(n) {\n  return n * n;\n}\nconsole.log(square(7));`,
      sol: `function square(n) {\n  return n * n;\n}\nconsole.log(square(7));`,
      pyStart: `def square(n):\n    # أكمل الدالة هنا\n    pass\n\nprint(square(7))`,
      pySol: `def square(n):\n    return n * n\n\nprint(square(7))`,
      expect: '49',
      hint: {
        ar: 'استبدل كلمة pass بالسطر: return n * n أو return n ** 2.',
        en: 'Replace pass with return n * n or return n ** 2.'
      }
    },
    qz: [
      {
        q: { ar: 'ما هو الدور الرئيسي للتعليمة return داخل الدالة؟', en: 'What is the primary role of the return statement inside a function?' },
        o: [
          { ar: 'طباعة القيمة مباشرة إلى شاشة العرض', en: 'Print the value directly to the display' },
          { ar: 'إرجاع القيمة الناتجة للمستدعي وإنهاء عمل الدالة فوراً', en: 'Return the computed value to the caller and terminate the function' },
          { ar: 'إعادة تشغيل الدالة من البداية', en: 'Restart the function from the beginning' },
          { ar: 'حذف المتغيرات من الذاكرة', en: 'Purge variables from memory' }
        ],
        a: 1,
        explanation: {
          ar: 'return تعيد النتيجة لمكان الاستدعاء وتخرج من الدالة مباشرة.',
          en: 'return passes back the result to the call-site and exits the function scope.'
        }
      },
      {
        q: { ar: 'ما هي الكلمة المفتاحية المستخدمة للإعلان عن دالة جديدة في بايثون؟', en: 'Which keyword is used to declare a function in Python?' },
        o: [
          { ar: 'function', en: 'function' },
          { ar: 'def', en: 'def' },
          { ar: 'fun', en: 'fun' },
          { ar: 'declare', en: 'declare' }
        ],
        a: 1,
        explanation: {
          ar: 'تستخدم بايثون الكلمة المختصرة def (اختصار define).',
          en: 'Python uses the keyword def (short for define) to declare functions.'
        }
      }
    ]
  },
  {
    id: 7,
    t: { ar: 'القوائم والمصفوفات (Lists & Arrays)', en: 'Lists & Arrays' },
    category: { ar: 'هياكل البيانات', en: 'Data Structures' },
    p: {
      ar: [
        'القائمة (List) هي هيكل بيانات مرتّب يسمح بتخزين عدة عناصر متسلسلة تحت اسم متغير واحد، مثل <code>fruits = ["apple", "banana", "mango"]</code>.',
        'كل عنصر في القائمة يمتلك <b>فهرساً (Index)</b> رقمياً يبدأ دائماً من <b>0</b>. فالعنصر الأول هو <code>fruits[0]</code>، والعنصر الأخير يمكن الوصول إليه بـ <code>fruits[-1]</code>.',
        'دوال مفيدة للقوائم: <code>append()</code> لإضافة عنصر جديد في النهاية، و<code>len()</code> لمعرفة عدد العناصر، و<code>sort()</code> للترتيب، و<code>pop()</code> لحذف عنصر.',
        'يمكن المرور على عناصر القائمة بسهولة وسلاسة باستخدام حلقة <code>for item in list:</code>.'
      ],
      en: [
        'A List is an ordered, mutable sequence that allows storing collections of items under a single variable identifier, such as <code>fruits = ["apple", "banana", "mango"]</code>.',
        'Items in a list are accessed via a zero-based <b>index</b>. The first item is <code>fruits[0]</code>, and the last item can be accessed using negative indexing: <code>fruits[-1]</code>.',
        'Essential list methods: <code>append()</code> to insert an item at the end, <code>len()</code> to get the element count, <code>sort()</code> to order elements, and <code>pop()</code> to remove an element.',
        'Iterating through lists is elegant and idiomatic with <code>for item in list:</code>.'
      ]
    },
    tips: [
      { ar: 'القوائم في بايثون يمكن أن تحتوي عناصر من أنواع مختلفة في نفس القائمة: data = [10, "Ali", True, 3.14]', en: 'Python lists can contain heterogeneous data types simultaneously: data = [10, "Ali", True, 3.14]' },
      { ar: 'للتقطيع (Slicing): list[1:3] تأخذ العناصر من الفهرس 1 حتى 2.', en: 'List slicing: list[1:3] extracts a sublist from index 1 up to index 2.' }
    ],
    ex: `let fruits = ["apple", "banana", "mango"];\nconsole.log(fruits[0]);\nfruits.push("grape");\nconsole.log(fruits.length);\nfor (let f of fruits) {\n  console.log(f);\n}`,
    py: `# إدارة القوائم في بايثون\nfruits = ["تفاح", "موز", "مانجو"]\nprint("العنصر الأول:", fruits[0])\n\n# إضافة عنصر جديد\nfruits.append("عنب")\nprint("عدد العناصر الإجمالي:", len(fruits))\n\n# استعراض جميع العناصر\nfor item in fruits:\n    print("فاكهة:", item)`,
    ch: {
      task: {
        ar: 'ابحث عن أكبر عدد في القائمة <code>nums = [4, 9, 2, 7]</code> واطبعه على الشاشة.',
        en: 'Find the largest number in the list <code>nums = [4, 9, 2, 7]</code> and print it.'
      },
      start: `let nums = [4, 9, 2, 7];\nlet max = nums[0];\nfor (let n of nums) {\n  if (n > max) max = n;\n}\nconsole.log(max);`,
      sol: `let nums = [4, 9, 2, 7];\nlet max = nums[0];\nfor (let n of nums) {\n  if (n > max) max = n;\n}\nconsole.log(max);`,
      pyStart: `nums = [4, 9, 2, 7]\nlargest = nums[0]\n# مر على القائمة وحدّث المتغير largest\nprint(largest)`,
      pySol: `nums = [4, 9, 2, 7]\nlargest = nums[0]\nfor n in nums:\n    if n > largest:\n        largest = n\nprint(largest)`,
      expect: '9',
      hint: {
        ar: 'استخدم حلقة for n in nums: وافحص إذا كان n > largest اجعل largest = n.',
        en: 'Use a loop for n in nums: and update largest = n if n > largest.'
      }
    },
    qz: [
      {
        q: { ar: 'ما هو رقم الفهرس (Index) لأول عنصر في أي مصفوفة أو قائمة برمجية؟', en: 'What is the index of the first element in any programming list or array?' },
        o: [
          { ar: '1', en: '1' },
          { ar: '0 (العد يبدأ دائماً من الصفر)', en: '0 (zero-based indexing)' },
          { ar: '-1', en: '-1' },
          { ar: 'يحدده المبرمج تلقائياً', en: 'Arbitrary' }
        ],
        a: 1,
        explanation: {
          ar: 'في بايثون ومعظم لغات البرمجة، يبدأ فهرس العناصر من الرقم 0.',
          en: 'In Python and modern languages, array indexing is zero-based.'
        }
      },
      {
        q: { ar: 'إذا كانت القائمة: nums = [10, 20, 30] فما ناتج الدالة len(nums)؟', en: 'If nums = [10, 20, 30], what does len(nums) evaluate to?' },
        o: [
          { ar: '2', en: '2' },
          { ar: '3 (عدد العناصر الثلاثة)', en: '3 (total number of elements)' },
          { ar: '30', en: '30' },
          { ar: '60', en: '60' }
        ],
        a: 1,
        explanation: {
          ar: 'دالة len تُرجع الطول أو العدد الفعلي للعناصر في القائمة وهو هنا 3.',
          en: 'The len() function returns the total count of elements, which is 3.'
        }
      }
    ]
  },
  {
    id: 8,
    t: { ar: 'حل المشكلات وتصحيح الأخطاء (Debugging)', en: 'Problem Solving & Debugging' },
    category: { ar: 'مهارات المبرمج', en: 'Core Engineering' },
    p: {
      ar: [
        'المبرمج المحترف يفكّر طويلاً ويحلل قبل أن يبدأ بكتابة الكود. خطوات حل أي مشكلة هندسية: <b>1. فهم المتطلبات</b> بدقة ← <b>2. التخطيط بالخطوات (Pseudocode)</b> ← <b>3. كتابة الكود</b> ← <b>4. الاختبار بحالات حدية (Edge Cases)</b> ← <b>5. التصحيح (Debugging)</b>.',
        'أنواع الأخطاء البرمجية: <b>خطأ الصياغة (Syntax Error)</b>: كنسيان قوس أو نقطتين <code>:</code>، ويكتشفه المفسر فوراً. <b>خطأ التشغيل (Runtime Error)</b>: كقسمة رقم على صفر <code>ZeroDivisionError</code>. <b>الخطأ المنطقي (Logic Error)</b>: الكود يعمل دون رسائل خطأ لكن النتيجة خاطئة، وهو الأكثر تحدياً.',
        'استراتيجيات تصحيح الأخطاء: تتبّع قيم المتغيرات بطباعتها باستخدام <code>print()</code> في مراحل متفرقة، وقراءة أول سطر وآخر سطر في تقرير الخطأ (Traceback).',
        'في مثال الدرس: نقوم بفحص مصفوفة أرقام، وعد الأرقام الزوجية بالتحقق من أن باقي قسمة العدد على 2 يساوي صفراً.'
      ],
      en: [
        'A seasoned software engineer analyzes thoroughly before typing. The systematic problem-solving cycle: <b>1. Understand requirements</b> → <b>2. Plan with pseudocode/flowcharts</b> → <b>3. Implement code</b> → <b>4. Test with edge cases</b> → <b>5. Debug and optimize</b>.',
        'Categories of software errors: <b>Syntax Errors</b> (e.g., missing colon or bracket; caught immediately by the interpreter), <b>Runtime Errors</b> (e.g., <code>ZeroDivisionError</code> during execution), and <b>Logic Errors</b> (code executes cleanly but yields incorrect output—the hardest to troubleshoot).',
        'Debugging tactics: insert exploratory <code>print()</code> statements to inspect state transformations, test with minimal inputs, and carefully dissect the interpreter Traceback.',
        'Lesson demonstration: iterating through numbers to count evens by testing if <code>n % 2 == 0</code>.'
      ]
    },
    tips: [
      { ar: 'عند ظهور خطأ، اقرأ اسم الخطأ والسطر المحدد في الـ Traceback فغالبًا ما يخبرك بالحقيقة بدقة.', en: 'When an exception is raised, read the exception type and exact line number indicated in the traceback.' },
      { ar: 'قسّم المشكلة المعقدة إلى دوال صغيرة يؤدي كل منها وظيفة واحدة بسيطة يمكن اختبارها بمفردها.', en: 'Decompose complex problems into small, single-responsibility functions that can be tested in isolation.' }
    ],
    ex: `// Count even numbers\nlet nums = [3, 8, 12, 5, 6];\nlet count = 0;\nfor (let n of nums) {\n  if (n % 2 === 0) count++;\n}\nconsole.log("Even numbers: " + count);`,
    py: `# خوارزمية عد الأعداد الزوجية في قائمة\nnums = [3, 8, 12, 5, 6]\ncount = 0\n\nfor n in nums:\n    if n % 2 == 0:\n        count += 1\n\nprint("الأعداد الزوجية:", count)`,
    ch: {
      task: {
        ar: 'اعدّ حروف العلة (a, e, i, o, u) في الكلمة <code>"programming"</code> واطبع العدد النهائي.',
        en: 'Count the vowels (a, e, i, o, u) in the word <code>"programming"</code> and print the total count.'
      },
      start: `let word = "programming";\nlet count = 0;\nfor (let ch of word) {\n  if ("aeiou".includes(ch)) count++;\n}\nconsole.log(count);`,
      sol: `let word = "programming";\nlet count = 0;\nfor (let ch of word) {\n  if ("aeiou".includes(ch)) count++;\n}\nconsole.log(count);`,
      pyStart: `word = "programming"\ncount = 0\n# عد حروف العلة واطبع النتيجة\nprint(count)`,
      pySol: `word = "programming"\ncount = 0\nfor ch in word:\n    if ch in "aeiou":\n        count += 1\nprint(count)`,
      expect: '3',
      hint: {
        ar: 'استخدم حلقة for ch in word: وافحص الشرط if ch in "aeiou": لزيادة count بمقدار 1.',
        en: 'Iterate with for ch in word: and check if ch in "aeiou": then increment count.'
      }
    },
    qz: [
      {
        q: { ar: 'برنامج يعمل دون أي رسائل تحذير أو أخطاء، لكنه يطبع نتيجة حسابية غير صحيحة. ما نوع هذا الخطأ؟', en: 'A program executes without throwing errors, but computes an incorrect answer. What type of bug is this?' },
        o: [
          { ar: 'خطأ صياغة (Syntax Error)', en: 'Syntax Error' },
          { ar: 'خطأ منطقي (Logic Error)', en: 'Logic Error' },
          { ar: 'عطل في المعالج المادي', en: 'Hardware Fault' },
          { ar: 'لا يعتبر خطأ برمجياً', en: 'Not an error' }
        ],
        a: 1,
        explanation: {
          ar: 'الخطأ المنطقي يعني أن الكود سليم لغوياً لكن طريقة الحساب أو خوارزمية الحل غير صحيحة.',
          en: 'A logic error indicates valid syntax but flawed reasoning or algorithmic calculation.'
        }
      },
      {
        q: { ar: 'ما هي أول خطوة منهجية يجب على مهندس البرمجيات اتخاذها لحل مسألة برمجية؟', en: 'What is the first methodical step an engineer should take to solve a software problem?' },
        o: [
          { ar: 'كتابة الكود مباشرة على لوحة المفاتيح', en: 'Immediately start typing code' },
          { ar: 'فهم وتحليل متطلبات المسألة والمدخلات والمخرجات المطلوبة', en: 'Carefully understand problem requirements, inputs, and expected outputs' },
          { ar: 'تشغيل أداة الفحص والتصحيح', en: 'Run a debugging tool' },
          { ar: 'نسخ حلول جاهزة دون تدقيق', en: 'Copy paste pre-existing snippets' }
        ],
        a: 1,
        explanation: {
          ar: 'فهم المسألة بدقة هو نصف الحل، ولا يُكتب الكود إلا بعد رسم الخطة والخوارزمية.',
          en: 'Thoroughly understanding specifications is paramount before committing to any code implementation.'
        }
      }
    ]
  }
];
