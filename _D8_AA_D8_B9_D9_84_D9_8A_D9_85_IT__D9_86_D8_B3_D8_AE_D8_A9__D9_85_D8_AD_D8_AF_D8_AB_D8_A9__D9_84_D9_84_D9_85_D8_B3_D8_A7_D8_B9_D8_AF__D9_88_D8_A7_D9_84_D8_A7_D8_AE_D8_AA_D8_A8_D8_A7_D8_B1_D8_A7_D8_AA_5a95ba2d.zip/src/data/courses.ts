import { ITCourse } from '../types';

export const IT_COURSES: ITCourse[] = [
  {
    id: 'python-core',
    title: { ar: 'Python — بايثون للمبتدئين والمتقدمين', en: 'Python Programming Essentials' },
    category: 'programming',
    level: 'beginner',
    description: {
      ar: 'أساسيات البرمجة، المتغيرات، أنواع البيانات، الجمل الشرطية، الحلقات التكرارية، الدوال، وهياكل البيانات وحل المشكلات التطبيقية.',
      en: 'Programming fundamentals, variables, dynamic data types, conditional branching, loops, functions, data structures, and practical problem-solving.'
    },
    keyTopics: [
      { ar: 'بنية اللغة وصياغة الكود', en: 'Syntax & Program Structure' },
      { ar: 'الجمل الشرطية والمنطق', en: 'Conditionals & Logic Flow' },
      { ar: 'الحلقات والقوائم والقواميس', en: 'Loops, Lists & Dictionaries' },
      { ar: 'الدوال والبرمجة التركيبية', en: 'Functions & Modular Code' }
    ],
    youtubeUrl: 'https://www.youtube.com/playlist?list=PLDoPjvoNmBAyE_gei5d18qkfIe-Z8mocs',
    badgeText: { ar: 'قائمة تشغيل متكاملة — Elzero', en: 'Full Playlist — Elzero' },
    hoursEst: 35
  },
  {
    id: 'java-oop',
    title: { ar: 'Java & OOP — جافا والبرمجة الكائنية', en: 'Java & Object-Oriented Programming' },
    category: 'programming',
    level: 'intermediate',
    description: {
      ar: 'مقدمة البرمجة كائنية التوجه، الفئات (Classes) والكائنات (Objects)، التغليف، الوراثة، وتعدد الأشكال وإعادة استخدام الكود في بيئات المؤسسات.',
      en: 'Introduction to OOP, classes and instances, encapsulation, inheritance, polymorphism, and enterprise-grade software architecture.'
    },
    keyTopics: [
      { ar: 'المفاهيم الكائنية الأساسية', en: 'Core OOP Principles' },
      { ar: 'الفئات والكائنات والمُنشئات', en: 'Classes, Objects & Constructors' },
      { ar: 'الوراثة والتجريد', en: 'Inheritance & Abstraction' },
      { ar: 'إدارة الاستثناءات والذاكرة', en: 'Exception Handling & Memory Management' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=شرح+Java+للمبتدئين+بالعربي',
    badgeText: { ar: 'شروحات جافا بالعربي', en: 'Arabic Java Tutorials' },
    hoursEst: 40
  },
  {
    id: 'it-essentials',
    title: { ar: 'IT Essentials — أساسيات تكنولوجيا المعلومات والعتاد', en: 'IT Essentials: Hardware & OS' },
    category: 'hardware',
    level: 'beginner',
    description: {
      ar: 'تشريح مكونات الحاسب المادية (اللوحة الأم، المعالج، الذاكرة، وحدات التخزين)، أنظمة التشغيل، تجميع الأجهزة، واكتشاف الأعطال والصيانة الوقائية.',
      en: 'PC hardware anatomy (Motherboards, CPUs, RAM, Storage, PSUs), Operating Systems, assembly, diagnostics, preventive maintenance, and safety.'
    },
    keyTopics: [
      { ar: 'عتاد الحاسوب ومكوناته الداخلية', en: 'Computer Hardware Architecture' },
      { ar: 'تثبيت أنظمة التشغيل وإدارتها', en: 'Operating System Installation' },
      { ar: 'استكشاف الأعطال وصيانة القطع', en: 'Hardware Troubleshooting' },
      { ar: 'الأمان المادي والكهربائي', en: 'Physical & Electrical Safety' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=IT+Essentials+شرح+عربي+مكونات+الكمبيوتر',
    badgeText: { ar: 'منهج Cisco IT Essentials', en: 'Cisco IT Essentials Course' },
    hoursEst: 30
  },
  {
    id: 'linux-essentials',
    title: { ar: 'Linux Essentials — أساسيات نظام لينكس والطرفية', en: 'Linux Essentials & Terminal Mastery' },
    category: 'systems',
    level: 'beginner',
    description: {
      ar: 'هيكل نظام الملفات، أوامر الطرفية المتقدمة (Bash CLI)، إدارة الصلاحيات والمستخدمين، العمليات، وحزم البرامج لإدارة الخوادم.',
      en: 'Filesystem hierarchy, command-line interface (Bash), user and permission management, processes, system utilities, and server administration.'
    },
    keyTopics: [
      { ar: 'أوامر الطرفية الأساسية والتنقل', en: 'CLI Navigation & Shell Commands' },
      { ar: 'أذونات الملفات والصلاحيات (chmod)', en: 'File Permissions & Users (chmod)' },
      { ar: 'إدارة العمليات والخدمات (systemd)', en: 'Process Management (systemd)' },
      { ar: 'كتابة سكريبتات Bash', en: 'Bash Scripting Automation' }
    ],
    youtubeUrl: 'https://www.youtube.com/watch?v=JBGnzEtimmg',
    badgeText: { ar: 'دورة لينكس شاملة بالعربي', en: 'Comprehensive Linux Course' },
    hoursEst: 25
  },
  {
    id: 'web-programming',
    title: { ar: 'Web Programming — تطوير وبرمجة الويب', en: 'Full-Stack Web Development' },
    category: 'programming',
    level: 'intermediate',
    description: {
      ar: 'بناء هيكل الصفحات باستخدام HTML5، والتنسيق الاحترافي والتصميم المتجاوب مع CSS3، والتفاعل الديناميكي مع JavaScript ومقدمة لـ Node.js.',
      en: 'Modern semantic HTML5, responsive CSS3 layouts and Flexbox/Grid, dynamic DOM manipulation with JavaScript, and server-side fundamentals.'
    },
    keyTopics: [
      { ar: 'هيكلة الويب باستخدام HTML5', en: 'Semantic HTML5 Structure' },
      { ar: 'التصميم المرن والمتجاوب CSS3', en: 'Modern Responsive CSS3 & Grid' },
      { ar: 'لغة التفاعل جافاسكريبت', en: 'JavaScript ES6+ & DOM Events' },
      { ar: 'الربط مع واجهات REST APIs', en: 'RESTful APIs & Fetch Integration' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=HTML+CSS+JavaScript+كورس+كامل+بالعربي',
    badgeText: { ar: 'مسار الويب الحديث', en: 'Modern Web Pathway' },
    hoursEst: 50
  },
  {
    id: 'database-sql',
    title: { ar: 'Database Systems & SQL — قواعد البيانات ولغة SQL', en: 'Relational Databases & SQL' },
    category: 'data',
    level: 'intermediate',
    description: {
      ar: 'تصميم قواعد البيانات العلائقية (ERD)، إنشاء الجداول وتطبيع البيانات (Normalization)، وكتابة استعلامات SQL المتقدمة والربط (Joins).',
      en: 'Relational database design (ERD), table schema modeling, normalization, CRUD operations, indexing, and advanced multi-table SQL queries.'
    },
    keyTopics: [
      { ar: 'تصميم المخططات وعلاقات الجداول', en: 'Schema Design & Normalization' },
      { ar: 'استعلامات SELECT و WHERE و GROUP', en: 'SQL Queries & Aggregations' },
      { ar: 'ربط الجداول (INNER / LEFT JOIN)', en: 'Multi-table Joins & Subqueries' },
      { ar: 'الفهارس وسرعة الاستعلامات', en: 'Indexes & Query Optimization' }
    ],
    youtubeUrl: 'https://www.youtube.com/watch?v=eFbCZKst5KE',
    badgeText: { ar: 'شرح مبسط لقواعد البيانات و SQL', en: 'Database & SQL Masterclass' },
    hoursEst: 28
  },
  {
    id: 'data-communication',
    title: { ar: 'Data Communication — اتصالات البيانات والإشارات', en: 'Data Communications & Transmission' },
    category: 'networks',
    level: 'intermediate',
    description: {
      ar: 'مبادئ انتقال الإشارات الرقمية والتناظرية، وسائط الإرسال السلكية واللاسلكية، التعديل والتضمين (Modulation)، والتحكم في تدفق وتصحيح الأخطاء.',
      en: 'Digital and analog transmission, guided and unguided physical media, modulation techniques, bandwidth, signal attenuation, and error detection.'
    },
    keyTopics: [
      { ar: 'الإشارات التناظرية والرقمية', en: 'Analog vs Digital Signaling' },
      { ar: 'كابلات الألياف والأسلاك النحاسية', en: 'Transmission Media (Fiber, Copper)' },
      { ar: 'طرق اكتشاف الأخطاء (CRC / Parity)', en: 'Error Detection & Correction' },
      { ar: 'تضمين الإشارة وتعديل التردد', en: 'Modulation & Multiplexing' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=Data+Communication+شرح+بالعربي+للمبتدئين',
    badgeText: { ar: 'شروحات اتصالات البيانات', en: 'Data Comms Lectures' },
    hoursEst: 24
  },
  {
    id: 'ccna-networking',
    title: { ar: 'CCNA & Networking — شبكات الحاسب وسيسكو', en: 'Computer Networks & CCNA' },
    category: 'networks',
    level: 'intermediate',
    description: {
      ar: 'نموذج OSI المكون من 7 طبقات، بروتوكولات TCP/IP، عناوين IPv4 و IPv6، تقسيم الشبكات الفرعية (Subnetting)، وأجهزة التوجيه والتحويل (Routers & Switches).',
      en: 'The 7-layer OSI model, TCP/IP stack, IPv4/IPv6 addressing, VLSM subnetting, routing protocols (OSPF), switching (VLANs), and network troubleshooting.'
    },
    keyTopics: [
      { ar: 'طبقات OSI السبعة ونموذج TCP/IP', en: '7-Layer OSI & TCP/IP Model' },
      { ar: 'تقسيم الشبكات (Subnetting & VLSM)', en: 'IPv4 Subnetting & Masking' },
      { ar: 'إعداد الـ Routers والـ Switches', en: 'Routing Protocols & Switching' },
      { ar: 'بروتوكولات DNS و DHCP و NAT', en: 'DNS, DHCP, ARP & NAT Services' }
    ],
    youtubeUrl: 'https://www.youtube.com/playlist?list=PLLlr6jKKdyK2cNjQnBcSfGab2k9KNsUmg',
    badgeText: { ar: 'قائمة CCNA المتكاملة', en: 'CCNA Complete Track' },
    hoursEst: 60
  },
  {
    id: 'cyber-security',
    title: { ar: 'Cyber Security — الأمن السيبراني وحماية النظم', en: 'Cybersecurity Fundamentals' },
    category: 'security',
    level: 'intermediate',
    description: {
      ar: 'مبادئ ثالوث الحماية CIA، تحليل الثغرات والتهديدات الأمنية، هجمات التصيد والاحتيال، جدران الحماية، أمن الأنظمة السحابية وسياسات الأمان.',
      en: 'The CIA Triad (Confidentiality, Integrity, Availability), threat landscapes, malware types, phishing defense, firewalls, and security policies.'
    },
    keyTopics: [
      { ar: 'ثالوث الحماية (CIA Triad)', en: 'CIA Triad & Defense in Depth' },
      { ar: 'أنواع التهديدات والهجمات الإلكترونية', en: 'Threat Vectors & Malware Analysis' },
      { ar: 'جدران الحماية وأنظمة كشف التسلل (IDS)', en: 'Firewalls & Intrusion Detection' },
      { ar: 'أفضل ممارسات تأمين الهوية والحسابات', en: 'Identity, IAM & Multi-Factor Auth' }
    ],
    youtubeUrl: 'https://maharatech.gov.eg/local/academy/cybersecurity-beginners.php?lang=ar',
    badgeText: { ar: 'أكاديمية مهارات تك الحكومية', en: 'Mahara-Tech Security Academy' },
    hoursEst: 35
  },
  {
    id: 'cryptography',
    title: { ar: 'Cryptography & Encryption — خوارزميات التشفير', en: 'Cryptography & Data Protection' },
    category: 'security',
    level: 'advanced',
    description: {
      ar: 'التشفير المتماثل (AES) وغير المتماثل (RSA)، دوال التجزئة الرياضية (SHA-256)، التوقيع الرقمي، شهادات SSL/TLS، وحماية الاتصالات الرقمية.',
      en: 'Symmetric encryption (AES) and asymmetric ciphers (RSA, ECC), cryptographic hashing (SHA-256), digital certificates, and TLS/HTTPS security.'
    },
    keyTopics: [
      { ar: 'التشفير المتماثل وغير المتماثل', en: 'Symmetric vs Asymmetric Ciphers' },
      { ar: 'دوال الهاش والتجزئة (Hashing)', en: 'Cryptographic Hash Functions' },
      { ar: 'الشهادات الرقمية وبروتوكول HTTPS', en: 'PKI, SSL/TLS & Handshake' },
      { ar: 'تأمين كلمات المرور والبيانات المخزنة', en: 'Password Salting & Storage at Rest' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=مقدمة+التشفير+Cryptography+بالعربي',
    badgeText: { ar: 'شروحات التشفير الحديث', en: 'Modern Cryptography' },
    hoursEst: 20
  },
  {
    id: 'iot-embedded',
    title: { ar: 'IoT — إنترنت الأشياء والأنظمة المدمجة', en: 'Internet of Things (IoT)' },
    category: 'systems',
    level: 'intermediate',
    description: {
      ar: 'ربط الحساسات والمشغلات (Sensors & Actuators) بالإنترنت، وحدات المتحكمات الدقيقة (Arduino / ESP32 / Raspberry Pi)، وبروتوكولات MQTT لنقل البيانات.',
      en: 'Connecting smart sensors and physical actuators to networks, microcontrollers (Arduino/ESP32/RPi), and lightweight messaging protocols like MQTT.'
    },
    keyTopics: [
      { ar: 'الحساسات والمتحكمات الدقيقة', en: 'Sensors & Microcontrollers' },
      { ar: 'بروتوكولات الاتصال (MQTT / CoAP)', en: 'Lightweight IoT Protocols (MQTT)' },
      { ar: 'تجميع بيانات الحساسات وتحليلها', en: 'Telemetry Data & Cloud Platforms' },
      { ar: 'أمان أجهزة إنترنت الأشياء', en: 'IoT Device Security & Privacy' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=Internet+of+Things+IoT+شرح+بالعربي',
    badgeText: { ar: 'شروحات إنترنت الأشياء', en: 'IoT Practical Guides' },
    hoursEst: 25
  },
  {
    id: 'english-ict',
    title: { ar: 'English for ICT — الإنجليزية التقنية المتخصصة', en: 'Technical English for IT Professionals' },
    category: 'skills',
    level: 'beginner',
    description: {
      ar: 'المصطلحات التقنية العالمية، كتابة التقارير وتوثيق الأنظمة البرمجية (Documentation)، قراءة الأدلة والمراجع، والتواصل في بيئات العمل الهندسية.',
      en: 'Global computing terminology, technical documentation, system specifications reading, RFC interpretation, and international engineering communication.'
    },
    keyTopics: [
      { ar: 'المصطلحات التقنية في البرمجة والشبكات', en: 'Core Computer Science Terminology' },
      { ar: 'قراءة الوثائق ومراجع الـ APIs', en: 'Reading API Documentation & Manuals' },
      { ar: 'كتابة تقارير الأعطال والتذاكر', en: 'Bug Reports & Ticketing Jargon' },
      { ar: 'المصطلحات في مقابلات العمل التقنية', en: 'Technical Job Interview Vocabulary' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=Technical+English+for+IT+beginners',
    badgeText: { ar: 'الإنجليزية لمجال الـ IT', en: 'Tech English Essentials' },
    hoursEst: 18
  },
  {
    id: 'mobile-apps',
    title: { ar: 'Mobile App Development — تطوير تطبيقات الهواتف', en: 'Mobile Applications Architecture' },
    category: 'programming',
    level: 'intermediate',
    description: {
      ar: 'تطوير تطبيقات الهواتف الذكية لأنظمة Android و iOS باستخدام تقنيات حديثة مثل Flutter أو React Native مع التركيز على تجربة المستخدم والأداء العالي.',
      en: 'Cross-platform mobile engineering for Android & iOS using Flutter or React Native, emphasizing responsive UX, offline storage, and APIs.'
    },
    keyTopics: [
      { ar: 'دورة حياة التطبيق (App Lifecycle)', en: 'Application Lifecycle & States' },
      { ar: 'إدارة الحالة والتخزين المحلي', en: 'State Management & Local Cache' },
      { ar: 'استهلاك الواجهات البرمجية APIs', en: 'RESTful API Services & Networking' },
      { ar: 'بناء الحزم ونشر التطبيقات', en: 'App Packaging & Store Deployment' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=تطوير+تطبيقات+الموبايل+والويب+للمبتدئين+بالعربي',
    badgeText: { ar: 'شروحات التطبيقات المتنقلة', en: 'Mobile App Engineering' },
    hoursEst: 45
  },
  {
    id: 'dsa-core',
    title: { ar: 'Algorithms & Data Structures — الخوارزميات وهياكل البيانات', en: 'Data Structures & Algorithms' },
    category: 'programming',
    level: 'advanced',
    description: {
      ar: 'تحليل التعقيد الزمني والمكاني (Big-O Notation)، المصفوفات والقوائم المترابطة، المكدسات (Stacks)، الطوابير (Queues)، والأشجار وخوارزميات البحث والفرز.',
      en: 'Big-O time/space complexity analysis, Linked Lists, Stacks, Queues, Binary Trees, Graph traversal, Sorting (Merge, Quick), and algorithmic design.'
    },
    keyTopics: [
      { ar: 'تحليل الأداء (Big-O Notation)', en: 'Time & Space Complexity (Big-O)' },
      { ar: 'المكدس والطابور (Stacks & Queues)', en: 'Linear Structures: Stacks & Queues' },
      { ar: 'خوارزميات الفرز والبحث الثنائي', en: 'Binary Search & Sorting Algorithms' },
      { ar: 'الأشجار والمخططات (Trees & Graphs)', en: 'Non-linear Structures & Graphs' }
    ],
    youtubeUrl: 'https://www.youtube.com/results?search_query=Data+Structures+and+Algorithms+بالعربي',
    badgeText: { ar: 'هياكل البيانات والخوارزميات', en: 'DSA Core Curriculum' },
    hoursEst: 45
  }
];
