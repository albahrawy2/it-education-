import { GlossaryTerm } from '../types';

export const GLOSSARY_TERMS: GlossaryTerm[] = [
  {
    id: 'term-algorithm',
    termEn: 'Algorithm',
    termAr: 'الخوارزمية',
    category: 'programming',
    definition: {
      ar: 'سلسلة من التعليمات المنطقية المتسلسلة والمحددة بدقة لحل مسألة معينة أو تنفيذ عملية حسابية.',
      en: 'A step-by-step procedure or set of logical rules to solve a specific problem or perform a task.'
    },
    example: {
      ar: 'خوارزمية البحث الثنائي (Binary Search) لإيجاد رقم في مصفوفة مرتبة في زمن قياسي.',
      en: 'Binary Search algorithm finding an element in a sorted array in O(log n) time.'
    }
  },
  {
    id: 'term-variable',
    termEn: 'Variable',
    termAr: 'المتغير',
    category: 'programming',
    definition: {
      ar: 'موقع تخزين محجوز في الذاكرة يحمل اسماً ويرتبط بقيمة يمكن أن تتغير أثناء عمل البرنامج.',
      en: 'A named memory location used to store a value that can be modified during program execution.'
    },
    example: {
      ar: 'score = 100 لتخزين نقاط اللاعب الحالية.',
      en: 'score = 100 used to hold a user\'s current score.'
    }
  },
  {
    id: 'term-compiler',
    termEn: 'Compiler',
    termAr: 'المُترجم (المصرّف)',
    category: 'systems',
    definition: {
      ar: 'برنامج حاسوبي يحوّل الشيفرة البرمجية المكتوبة بلغة عالية المستوى بالكامل إلى لغة الآلة (Machine Code) قبل التشغيل.',
      en: 'A system software that transforms entire source code written in a high-level language into machine code prior to execution.'
    },
    example: {
      ar: 'مترجم GCC للغة C ومترجم javac للغة Java.',
      en: 'GCC for C/C++ or javac for Java.'
    }
  },
  {
    id: 'term-interpreter',
    termEn: 'Interpreter',
    termAr: 'المُفسّر',
    category: 'systems',
    definition: {
      ar: 'برنامج ينفّذ أوامر الشيفرة البرمجية مباشرة سطراً بسطر دون الحاجة لترجمتها مسبقاً إلى ملف تنفيذي منفصل.',
      en: 'A computer program that directly executes source code instructions line by line without prior compilation into machine code.'
    },
    example: {
      ar: 'مفسر لغة Python ومحرك V8 للغة JavaScript.',
      en: 'The standard CPython runtime interpreter.'
    }
  },
  {
    id: 'term-ip-address',
    termEn: 'IP Address',
    termAr: 'عنوان بروتوكول الإنترنت (IP)',
    category: 'networks',
    definition: {
      ar: 'معرف رقمي فريد يُعين لكل جهاز متصل بشبكة حاسوبية تستخدم بروتوكول الإنترنت للاتصال وتحديد موقعه.',
      en: 'A unique numerical label assigned to each device connected to a computer network that uses the Internet Protocol for communication.'
    },
    example: {
      ar: '192.168.1.1 (عنوان IPv4 محلي) و 2001:0db8:: (عنوان IPv6).',
      en: '192.168.1.1 (IPv4 private address) or 2001:0db8:: (IPv6).'
    }
  },
  {
    id: 'term-dns',
    termEn: 'DNS (Domain Name System)',
    termAr: 'نظام أسماء النطاقات (DNS)',
    category: 'networks',
    definition: {
      ar: 'دليل هاتف الإنترنت الذي يقوم بترجمة أسماء النطاقات السهلة الحفظ (مثل google.com) إلى عناوين IP الرقمية المقابلة لها.',
      en: 'The internet\'s phonebook that resolves human-readable domain names (e.g. google.com) into numeric IP addresses.'
    },
    example: {
      ar: 'تحويل النطاق www.mohamed.edu إلى عنوان الـ IP رقم 142.250.185.206.',
      en: 'Resolving domain.org to 142.250.185.206.'
    }
  },
  {
    id: 'term-firewall',
    termEn: 'Firewall',
    termAr: 'جدار الحماية (الجدار الناري)',
    category: 'security',
    definition: {
      ar: 'نظام أمان شبكي يراقب ويتحكم في حركة مرور البيانات الواردة والصادرة استناداً إلى قواعد أمان محددة مسبقاً.',
      en: 'A network security device that monitors and filters incoming and outgoing network traffic based on an organization’s previously established security policies.'
    },
    example: {
      ar: 'حظر المنافذ غير الآمنة والسماح فقط بحركة مرور المنفذ 443 (HTTPS).',
      en: 'Blocking unauthorized ports while permitting encrypted port 443 (HTTPS).'
    }
  },
  {
    id: 'term-encryption',
    termEn: 'Encryption',
    termAr: 'التشفير (التعمية)',
    category: 'security',
    definition: {
      ar: 'عملية تحويل البيانات من نصها المقروء الصريح إلى نص مشفر غير مفهوم لمنع غير المصرح لهم من قراءته، باستخدام مفتاح سري.',
      en: 'The process of encoding data from plaintext to ciphertext using cryptographic algorithms and keys to prevent unauthorized access.'
    },
    example: {
      ar: 'تشفير AES-256 المستخدم لتأمين الملفات والمعاملات البنكية.',
      en: 'AES-256 encryption securing financial transactions and storage.'
    }
  },
  {
    id: 'term-sql',
    termEn: 'SQL (Structured Query Language)',
    termAr: 'لغة الاستعلام البنيوية (SQL)',
    category: 'data',
    definition: {
      ar: 'لغة معيارية متخصصة لإدارة واسترجاع وتعديل البيانات المخزنة داخل أنظمة قواعد البيانات العلائقية (RDBMS).',
      en: 'A standardized domain-specific programming language used to manage, query, and manipulate data in relational database management systems.'
    },
    example: {
      ar: 'SELECT name, email FROM students WHERE grade >= 85;',
      en: 'SELECT name, email FROM students WHERE grade >= 85;'
    }
  },
  {
    id: 'term-cache',
    termEn: 'Cache Memory',
    termAr: 'الذاكرة المخبئية (الكاش)',
    category: 'hardware',
    definition: {
      ar: 'ذاكرة فائقة السرعة تقع بين المعالج والذاكرة الرئيسية (RAM)، تخزن البيانات التي يتكرر استخدامها لتسريع الوصول إليها.',
      en: 'A high-speed hardware or software component that stores recently or frequently accessed data so future requests can be served faster.'
    },
    example: {
      ar: 'ذاكرة L1 و L2 و L3 المدمجة داخل معالجات الحواسيب الحديثة.',
      en: 'CPU L1/L2/L3 cache memory tiers or browser HTTP cache.'
    }
  },
  {
    id: 'term-api',
    termEn: 'API (Application Programming Interface)',
    termAr: 'واجهة برمجة التطبيقات (API)',
    category: 'programming',
    definition: {
      ar: 'مجموعة من القواعد والبروتوكولات التي تسمح لبرنامجين مختلفين بالتواصل وتبادل البيانات والخدمات فيما بينهما بسلاسة.',
      en: 'A software intermediary that defines mechanisms and rules allowing two distinct applications to communicate with each other.'
    },
    example: {
      ar: 'استدعاء API الطقس لعرض درجات الحرارة الحالية في تطبيق الموبايل.',
      en: 'Consuming a Weather REST API to display forecasts on a mobile app.'
    }
  },
  {
    id: 'term-cloud-computing',
    termEn: 'Cloud Computing',
    termAr: 'الحوسبة السحابية',
    category: 'systems',
    definition: {
      ar: 'توفير موارد تقنية المعلومات عبر الإنترنت حسب الطلب، مثل الخوادم، والتخزين، وقواعد البيانات، والشبكات بنموذج الدفع حسب الاستخدام.',
      en: 'The on-demand delivery of IT resources over the Internet with pay-as-you-go pricing, including compute power, storage, and databases.'
    },
    example: {
      ar: 'منصات Google Cloud Platform (GCP) و AWS و Microsoft Azure.',
      en: 'Google Cloud Platform (GCP), AWS, and Azure cloud services.'
    }
  },
  {
    id: 'term-git',
    termEn: 'Git & Version Control',
    termAr: 'نظام إدارة الإصدارات (Git)',
    category: 'programming',
    definition: {
      ar: 'نظام موزع لتتبع التغييرات في الشيفرة المصدرية أثناء تطوير البرمجيات، وتنسيق العمل المشترك بين عدة مبرمجين.',
      en: 'A distributed version control system designed to track changes in source code and coordinate collaborative workflows among software engineers.'
    },
    example: {
      ar: 'أوامر git commit و git push و git merge لحفظ التعديلات ودمجها.',
      en: 'Commands git commit, git push, and git branch for revision tracking.'
    }
  },
  {
    id: 'term-big-o',
    termEn: 'Big-O Notation',
    termAr: 'ترميز بيج أو (تحليل التعقيد)',
    category: 'programming',
    definition: {
      ar: 'مفهوم رياضي يُستخدم في علوم الحاسوب لوصف كفاءة وسلوك الخوارزميات من حيث الوقت المستغرق أو الذاكرة المستهلكة مع زيادة حجم المدخلات.',
      en: 'A mathematical notation used in computer science to describe the limiting behavior and asymptotic efficiency of algorithms as input size grows.'
    },
    example: {
      ar: 'الوصول لعنصر في مصفوفة يتم بزمن O(1)، بينما البحث الخطي يستغرق O(n).',
      en: 'Array index access is O(1) constant time, while linear search is O(n).'
    }
  },
  {
    id: 'term-cia-triad',
    termEn: 'CIA Triad',
    termAr: 'ثالوث الحماية (السرية، السلامة، التوافر)',
    category: 'security',
    definition: {
      ar: 'النموذج الأمني الأساسي المعتمد عالمياً: السرية (Confidentiality)، وسلامة البيانات (Integrity)، وتوافر الخدمة (Availability).',
      en: 'The benchmark model for cybersecurity policy: Confidentiality (secrecy), Integrity (trustworthiness), and Availability (accessibility).'
    },
    example: {
      ar: 'منع هجمات DoS يضمن التوافر (Availability)، والتشفير يضمن السرية (Confidentiality).',
      en: 'Mitigating DDoS attacks protects Availability; encryption maintains Confidentiality.'
    }
  },
  {
    id: 'term-iot',
    termEn: 'IoT (Internet of Things)',
    termAr: 'إنترنت الأشياء',
    category: 'systems',
    definition: {
      ar: 'شبكة من الأجهزة والأشياء المادية المزودة بحساسات وبرمجيات تتيح لها الاتصال وتبادل البيانات مع أجهزة أخرى عبر الإنترنت.',
      en: 'A network of physical objects embedded with sensors, processing ability, and software that connect and exchange data over communication networks.'
    },
    example: {
      ar: 'العدادات الذكية، والمنازل الذكية، والحساسات الزراعية المرتبطة بالإنترنت.',
      en: 'Smart thermostats, industrial sensors, and connected automotive systems.'
    }
  }
];
