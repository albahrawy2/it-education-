import React, { useState, useEffect } from 'react';
import { 
  Play, 
  RotateCcw, 
  CheckCircle, 
  XCircle, 
  Lightbulb, 
  HelpCircle, 
  ChevronRight, 
  ChevronLeft, 
  Copy, 
  Check, 
  Terminal as TerminalIcon,
  Sparkles,
  Info,
  Clock,
  Eye,
  Key
} from 'lucide-react';
import { Lesson, AppState, RunResult, Language } from '../types';
import { executePython } from '../services/pythonRunner';

interface LessonsViewProps {
  lessons: Lesson[];
  state: AppState;
  onSelectLesson: (idx: number) => void;
  onLessonComplete: (idx: number) => void;
  onQuizAnswer: (key: string, ansIdx: number) => void;
}

export const LessonsView: React.FC<LessonsViewProps> = ({
  lessons,
  state,
  onSelectLesson,
  onLessonComplete,
  onQuizAnswer,
}) => {
  const currentIdx = state.currentLesson;
  const currentLesson = lessons[currentIdx] || lessons[0];
  const isEn = state.lang === 'en';
  const isBoth = state.lang === 'both';

  // Example editor state
  const [exCode, setExCode] = useState(currentLesson.py);
  const [exInput, setExInput] = useState('');
  const [exResult, setExResult] = useState<RunResult | null>(null);
  const [exRunning, setExRunning] = useState(false);
  const [copiedEx, setCopiedEx] = useState(false);

  // Challenge editor state
  const [chCode, setChCode] = useState(currentLesson.ch.pyStart || '# اكتب كود الحل هنا\n');
  const [chResult, setChResult] = useState<RunResult | null>(null);
  const [chRunning, setChRunning] = useState(false);
  const [chPassed, setChPassed] = useState<boolean | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [showSolution, setShowSolution] = useState(false);
  const [copiedSol, setCopiedSol] = useState(false);

  // Sync state when lesson changes
  useEffect(() => {
    setExCode(currentLesson.py);
    setExInput('');
    setExResult(null);
    setChCode(currentLesson.ch.pyStart || '# اكتب كود الحل هنا\n');
    setChResult(null);
    setChPassed(state.completedLessons[currentIdx] ? true : null);
    setShowHint(false);
    setShowSolution(false);
  }, [currentIdx, currentLesson, state.completedLessons]);

  // Handle Tab key in textareas
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>, setter: (val: string) => void) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const val = target.value;
      const newVal = val.substring(0, start) + '    ' + val.substring(end);
      setter(newVal);
      setTimeout(() => {
        target.selectionStart = target.selectionEnd = start + 4;
      }, 0);
    }
  };

  // Run Example
  const handleRunExample = async () => {
    setExRunning(true);
    try {
      const res = await executePython(exCode, exInput);
      setExResult(res);
    } catch (err: any) {
      setExResult({ out: [], err: String(err) });
    } finally {
      setExRunning(false);
    }
  };

  // Reset Example
  const handleResetExample = () => {
    setExCode(currentLesson.py);
    setExInput('');
    setExResult(null);
  };

  // Run Challenge
  const handleRunChallenge = async () => {
    setChRunning(true);
    try {
      const res = await executePython(chCode, '');
      setChResult(res);

      const stdout = (res.out || []).join('\n').trim();
      const expected = currentLesson.ch.expect.trim();

      if (!res.err && stdout === expected) {
        setChPassed(true);
        onLessonComplete(currentIdx);
      } else {
        setChPassed(false);
      }
    } catch (err: any) {
      setChResult({ out: [], err: String(err) });
      setChPassed(false);
    } finally {
      setChRunning(false);
    }
  };

  // Reset Challenge
  const handleResetChallenge = () => {
    setChCode(currentLesson.ch.pyStart || '# اكتب كود الحل هنا\n');
    setChResult(null);
    setChPassed(null);
    setShowHint(false);
  };

  const copyToClipboard = (text: string, setStatus: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setStatus(true);
    setTimeout(() => setStatus(false), 2000);
  };

  const renderBilingual = (textObj: { ar: string; en: string }, className?: string) => {
    if (isBoth) {
      return (
        <div className={`space-y-1 ${className || ''}`}>
          <div className="font-medium text-slate-800 dark:text-slate-200" dir="rtl">{textObj.ar}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-sans" dir="ltr">{textObj.en}</div>
        </div>
      );
    }
    return (
      <span className={className} dir={isEn ? 'ltr' : 'rtl'}>
        {isEn ? textObj.en : textObj.ar}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Lessons Horizontal Navigation Chips */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-2 shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
          {lessons.map((lesson, idx) => {
            const isCur = idx === currentIdx;
            const isDone = !!state.completedLessons[idx];
            return (
              <button
                key={lesson.id}
                onClick={() => onSelectLesson(idx)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                  isCur
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-500/25 scale-[1.02]'
                    : isDone
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/80 hover:bg-emerald-100'
                    : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <span className="font-mono text-[11px] font-bold opacity-80">{idx + 1}</span>
                <span>{isEn ? lesson.t.en : lesson.t.ar}</span>
                {isDone && (
                  <CheckCircle className={`w-3.5 h-3.5 ${isCur ? 'text-white' : 'text-emerald-600 dark:text-emerald-400'}`} />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Left/Right layout on large screens */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Lesson Concepts & Theory & Quizzes (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Lesson Header Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-wider uppercase text-blue-600 dark:text-blue-400">
                {isEn ? `LESSON ${currentIdx + 1} OF ${lessons.length}` : `الدرس ${currentIdx + 1} من ${lessons.length}`}
              </span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-medium">
                {isEn ? currentLesson.category.en : currentLesson.category.ar}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-4">
              {isEn ? currentLesson.t.en : currentLesson.t.ar}
            </h2>
            {isBoth && (
              <p className="text-sm font-sans text-slate-500 dark:text-slate-400 mb-4 -mt-2" dir="ltr">
                {currentLesson.t.en}
              </p>
            )}

            {/* Paragraphs */}
            <div className="space-y-4 text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              {currentLesson.p.ar.map((arPara, pIdx) => {
                const enPara = currentLesson.p.en[pIdx] || '';
                return (
                  <div key={pIdx} className="space-y-1">
                    {!isEn && (
                      <p 
                        dir="rtl" 
                        dangerouslySetInnerHTML={{ __html: arPara }} 
                        className="leading-relaxed"
                      />
                    )}
                    {(isEn || isBoth) && (
                      <p 
                        dir="ltr" 
                        dangerouslySetInnerHTML={{ __html: enPara }} 
                        className={`${isBoth ? 'text-xs text-slate-500 dark:text-slate-400 font-sans' : 'leading-relaxed'}`}
                      />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Pro Tips Callout */}
            {currentLesson.tips && currentLesson.tips.length > 0 && (
              <div className="mt-6 p-4 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-xs sm:text-sm">
                <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-300 mb-2">
                  <Lightbulb className="w-4 h-4 text-amber-600" />
                  <span>{isEn ? 'Pro Engineering Tips:' : 'نصائح المبرمج المحترف:'}</span>
                </div>
                <ul className="space-y-2 text-amber-900/90 dark:text-amber-200/90 list-disc list-inside">
                  {currentLesson.tips.map((tip, tIdx) => (
                    <li key={tIdx} className="leading-relaxed">
                      {isBoth ? `${tip.ar} — (${tip.en})` : isEn ? tip.en : tip.ar}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Quick Quiz Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  {isEn ? 'Knowledge Check Quiz' : 'اختبر معلوماتك في هذا الدرس'}
                </h3>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {currentLesson.qz.length} {isEn ? 'Questions' : 'أسئلة'}
              </span>
            </div>

            <div className="space-y-6">
              {currentLesson.qz.map((quizItem, qIdx) => {
                const answerKey = `${currentIdx}-${qIdx}`;
                const chosenAns = state.quizAnswers[answerKey];
                const isAnswered = chosenAns !== undefined;

                return (
                  <div key={qIdx} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 space-y-3">
                    <div className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                      <span className="text-blue-600 dark:text-blue-400 ml-2 font-mono">Q{qIdx + 1}.</span>
                      {renderBilingual(quizItem.q)}
                    </div>

                    <div className="grid grid-cols-1 gap-2 pt-1">
                      {quizItem.o.map((opt, oIdx) => {
                        let btnStyle = 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-400 hover:bg-blue-50/50 dark:hover:bg-slate-800';

                        if (isAnswered) {
                          if (oIdx === quizItem.a) {
                            btnStyle = 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 border-emerald-500 font-bold';
                          } else if (oIdx === chosenAns) {
                            btnStyle = 'bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200 border-rose-400';
                          } else {
                            btnStyle = 'opacity-40 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800';
                          }
                        }

                        return (
                          <button
                            key={oIdx}
                            disabled={isAnswered}
                            onClick={() => onQuizAnswer(answerKey, oIdx)}
                            className={`flex items-start justify-between p-3 rounded-xl text-xs sm:text-sm text-right transition-all border ${btnStyle}`}
                          >
                            <span className="flex-1">{renderBilingual(opt)}</span>
                            {isAnswered && oIdx === quizItem.a && (
                              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 ml-2 mt-0.5" />
                            )}
                            {isAnswered && oIdx === chosenAns && oIdx !== quizItem.a && (
                              <XCircle className="w-4 h-4 text-rose-600 shrink-0 ml-2 mt-0.5" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Quiz Explanation callout */}
                    {isAnswered && quizItem.explanation && (
                      <div className={`p-3 rounded-lg text-xs leading-relaxed border ${
                        chosenAns === quizItem.a
                          ? 'bg-emerald-100/60 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800'
                          : 'bg-amber-100/60 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 border-amber-300 dark:border-amber-800'
                      }`}>
                        <div className="font-bold mb-1">
                          {chosenAns === quizItem.a 
                            ? (isEn ? '✓ Correct Answer!' : '✓ إجابة صحيحة!') 
                            : (isEn ? '✗ Not quite. Here is why:' : '✗ إجابة غير دقيقة. التوضيح:')}
                        </div>
                        <div>{renderBilingual(quizItem.explanation)}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Code Editor & Challenge Box (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Card: Try the Example (محرر المثال التفاعلي) */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden text-slate-100">
            {/* Window title bar */}
            <div className="bg-slate-950/80 px-4 py-3 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <span className="text-xs font-mono text-slate-400 font-semibold ml-2">
                  example.py
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => copyToClipboard(exCode, setCopiedEx)}
                  className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                  title="نسخ الكود"
                >
                  {copiedEx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={handleResetExample}
                  className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                  title="إعادة الكود الأصلي"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Code Textarea */}
            <div className="p-3">
              <textarea
                value={exCode}
                onChange={(e) => setExCode(e.target.value)}
                onKeyDown={(e) => handleKeyDown(e, setExCode)}
                spellCheck={false}
                autoCapitalize="off"
                autoComplete="off"
                rows={7}
                dir="ltr"
                className="w-full bg-slate-950 font-mono text-xs sm:text-sm text-cyan-300 p-3 rounded-xl border border-slate-800 focus:outline-hidden focus:border-blue-500 transition-colors resize-y leading-relaxed"
                placeholder="# اكتب كود بايثون هنا..."
              />

              {/* Optional Stdin input */}
              <div className="mt-2 space-y-1">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{isEn ? 'Program Input (stdin - for input() calls):' : 'مدخلات البرنامج (اختياري - لدوال input):'}</span>
                </div>
                <textarea
                  value={exInput}
                  onChange={(e) => setExInput(e.target.value)}
                  placeholder={isEn ? "e.g. 21\nAli" : "مثال:\n21\nMohamed"}
                  rows={2}
                  dir="ltr"
                  className="w-full bg-slate-950 font-mono text-xs text-amber-300 p-2 rounded-lg border border-slate-800 focus:outline-hidden focus:border-amber-500 resize-none"
                />
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-between mt-3">
                <button
                  onClick={handleRunExample}
                  disabled={exRunning}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <Play className={`w-4 h-4 fill-current ${exRunning ? 'animate-spin' : ''}`} />
                  <span>{exRunning ? (isEn ? 'Executing...' : 'جارٍ التشغيل...') : (isEn ? 'Run Code' : 'تشغيل الكود')}</span>
                </button>

                <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
                  <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Python 3.10 Engine</span>
                </div>
              </div>
            </div>

            {/* Output Console Box */}
            <div className="bg-slate-950 p-4 border-t border-slate-800/80 font-mono text-xs space-y-1 min-h-[90px]">
              <div className="flex items-center justify-between text-[11px] text-slate-400 pb-1 border-b border-slate-800/60 mb-2">
                <span>{isEn ? 'Terminal Output:' : 'مخرجات الكود:'}</span>
                {exResult?.execTimeMs !== undefined && (
                  <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {exResult.execTimeMs}ms
                  </span>
                )}
              </div>

              {exResult ? (
                <>
                  {exResult.out.length > 0 && (
                    <div className="space-y-0.5 text-emerald-400 whitespace-pre-wrap select-text">
                      {exResult.out.map((line, lIdx) => (
                        <div key={lIdx} dir="ltr">{line}</div>
                      ))}
                    </div>
                  )}
                  {exResult.err && (
                    <div className="text-rose-400 bg-rose-950/40 p-2 rounded-md border border-rose-900/60 whitespace-pre-wrap" dir="ltr">
                      {exResult.err}
                    </div>
                  )}
                  {exResult.out.length === 0 && !exResult.err && (
                    <div className="text-slate-500 italic">
                      {isEn ? '(Program finished with no output. Did you forget print()?)' : '(انتهى البرنامج بدون مخرجات. هل استخدمت دالة print()؟)'}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-slate-600 italic">
                  {isEn ? 'Press "Run Code" to view the terminal output...' : 'اضغط "تشغيل الكود" لمعاينة النتيجة هنا...'}
                </div>
              )}
            </div>
          </div>

          {/* Card: Lesson Coding Challenge (التحدي البرمجي) */}
          <div className="bg-gradient-to-br from-indigo-950/90 via-slate-900 to-slate-950 rounded-2xl border border-indigo-900/40 shadow-xl p-5 text-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600/40 border border-indigo-500/50 flex items-center justify-center text-indigo-300">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">
                    {isEn ? 'Lesson Coding Challenge' : 'التحدي البرمجي للدرس'}
                  </h3>
                  <p className="text-[11px] text-indigo-200">
                    {isEn ? 'Write the solution and test your code' : 'اكتب كود الحل وتحقق من صحة نتيجته'}
                  </p>
                </div>
              </div>

              {chPassed && (
                <span className="flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-800">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Solved!' : 'تم الحل بنجاح!'}</span>
                </span>
              )}
            </div>

            {/* Task prompt */}
            <div className="p-3.5 rounded-xl bg-indigo-950/60 border border-indigo-800/40 text-xs sm:text-sm text-indigo-100">
              <div 
                dangerouslySetInnerHTML={{ 
                  __html: isEn ? currentLesson.ch.task.en : currentLesson.ch.task.ar 
                }}
                className="leading-relaxed font-medium"
              />
              <div className="mt-2 text-[11px] font-mono text-cyan-300">
                {isEn ? 'Expected Output: ' : 'النتيجة المتوقعة: '}
                <span className="bg-slate-900 px-2 py-0.5 rounded-md border border-cyan-800/60 text-cyan-200 font-bold">
                  {currentLesson.ch.expect}
                </span>
              </div>
            </div>

            {/* Challenge Editor */}
            <textarea
              value={chCode}
              onChange={(e) => setChCode(e.target.value)}
              onKeyDown={(e) => handleKeyDown(e, setChCode)}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              rows={6}
              dir="ltr"
              className="w-full bg-slate-950 font-mono text-xs sm:text-sm text-emerald-300 p-3 rounded-xl border border-indigo-900/60 focus:outline-hidden focus:border-indigo-400 transition-colors resize-y leading-relaxed"
              placeholder="# اكتب كود الحل هنا..."
            />

            {/* Controls */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunChallenge}
                  disabled={chRunning}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <Play className={`w-4 h-4 fill-current ${chRunning ? 'animate-spin' : ''}`} />
                  <span>{chRunning ? (isEn ? 'Testing...' : 'جارٍ الاختبار...') : (isEn ? 'Run & Check' : 'تشغيل وتحقق')}</span>
                </button>
                <button
                  onClick={handleResetChallenge}
                  className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                  title="إعادة التعيين"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex items-center gap-2 text-xs">
                {currentLesson.ch.hint && (
                  <button
                    onClick={() => setShowHint(!showHint)}
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium transition-colors"
                  >
                    <Lightbulb className="w-3.5 h-3.5" />
                    <span>{showHint ? (isEn ? 'Hide Hint' : 'إخفاء التلميح') : (isEn ? 'Hint' : 'تلميح')}</span>
                  </button>
                )}
                <button
                  onClick={() => setShowSolution(!showSolution)}
                  className="text-indigo-300 hover:text-white flex items-center gap-1 font-medium transition-colors"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>{showSolution ? (isEn ? 'Hide Solution' : 'إخفاء الحل') : (isEn ? 'Show Solution' : 'الحل النموذجي')}</span>
                </button>
              </div>
            </div>

            {/* Hint Box */}
            {showHint && currentLesson.ch.hint && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-xs text-amber-200 leading-relaxed">
                <span className="font-bold ml-1">💡 {isEn ? 'Hint:' : 'تلميح:'}</span>
                {isEn ? currentLesson.ch.hint.en : currentLesson.ch.hint.ar}
              </div>
            )}

            {/* Solution Box */}
            {showSolution && (
              <div className="p-3 rounded-xl bg-slate-950 border border-indigo-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs text-indigo-300 font-semibold">
                  <span>{isEn ? 'Verified Python Solution:' : 'الحل النموذجي المعتمد:'}</span>
                  <button
                    onClick={() => copyToClipboard(currentLesson.ch.pySol, setCopiedSol)}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
                  >
                    {copiedSol ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedSol ? (isEn ? 'Copied' : 'تم النسخ') : (isEn ? 'Copy' : 'نسخ')}</span>
                  </button>
                </div>
                <pre className="p-2.5 rounded-lg bg-slate-900 font-mono text-xs text-cyan-300 overflow-x-auto" dir="ltr">
                  {currentLesson.ch.pySol}
                </pre>
              </div>
            )}

            {/* Challenge Result Banner */}
            {chResult && (
              <div className={`p-3.5 rounded-xl border text-xs sm:text-sm font-medium ${
                chPassed
                  ? 'bg-emerald-950/60 border-emerald-500/80 text-emerald-200'
                  : 'bg-rose-950/60 border-rose-500/80 text-rose-200'
              }`}>
                {chPassed ? (
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <div className="font-bold text-emerald-300">
                        {isEn ? '🎉 Outstanding! Challenge Passed.' : '🎉 أحسنت صنعًا! إجابتك صحيحة ومطابقة.'}
                      </div>
                      <div className="text-xs text-emerald-400/90 mt-0.5">
                        {isEn ? 'Your progress has been recorded and saved.' : 'تم تسجيل نجاحك وتحديث تقدمك التعليمي بنجاح.'}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 font-bold text-rose-300">
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{isEn ? 'Not quite match. Keep trying!' : 'النتيجة غير مطابقة للمطلوب بعد. راجع الكود وحاول ثانية.'}</span>
                    </div>
                    {chResult.err && (
                      <div className="font-mono text-xs bg-slate-950 p-2 rounded text-rose-400" dir="ltr">
                        {chResult.err}
                      </div>
                    )}
                    <div className="text-xs">
                      <span>{isEn ? 'Your output: ' : 'ناتج كودك الحالي: '}</span>
                      <code className="bg-slate-950 px-2 py-0.5 rounded text-amber-300 font-mono" dir="ltr">
                        {chResult.out.join('\n') || '—'}
                      </code>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
        <button
          onClick={() => {
            if (currentIdx > 0) {
              onSelectLesson(currentIdx - 1);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          disabled={currentIdx === 0}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-bold text-xs sm:text-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          <ChevronRight className="w-4 h-4" />
          <span>{isEn ? 'Previous Lesson' : 'الدرس السابق'}</span>
        </button>

        <span className="text-xs text-slate-500 font-mono">
          {currentIdx + 1} / {lessons.length}
        </span>

        <button
          onClick={() => {
            if (currentIdx < lessons.length - 1) {
              onSelectLesson(currentIdx + 1);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          disabled={currentIdx === lessons.length - 1}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          <span>{isEn ? 'Next Lesson' : 'الدرس التالي'}</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
