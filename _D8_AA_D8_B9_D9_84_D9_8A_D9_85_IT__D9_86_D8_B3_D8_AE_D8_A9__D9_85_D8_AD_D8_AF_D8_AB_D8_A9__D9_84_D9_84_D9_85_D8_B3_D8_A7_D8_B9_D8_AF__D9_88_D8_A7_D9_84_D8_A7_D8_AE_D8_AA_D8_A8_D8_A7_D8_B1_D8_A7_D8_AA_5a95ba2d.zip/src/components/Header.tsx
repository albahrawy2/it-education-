import React from 'react';
import { 
  BookOpen, 
  Terminal, 
  Library, 
  BookMarked, 
  Workflow, 
  Award, 
  Moon, 
  Sun, 
  Languages,
  CheckCircle2,
  Sparkles,
  BrainCircuit,
  ListChecks
} from 'lucide-react';
import { Language, AppState } from '../types';

interface HeaderProps {
  state: AppState;
  totalLessons: number;
  completedCount: number;
  onLanguageChange: (lang: Language) => void;
  onThemeToggle: () => void;
  onTabChange: (tab: AppState['activeTab']) => void;
  onOpenCertificate: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  totalLessons,
  completedCount,
  onLanguageChange,
  onThemeToggle,
  onTabChange,
  onOpenCertificate
}) => {
  const isEn = state.lang === 'en';
  const progressPercent = Math.round((completedCount / totalLessons) * 100);

  const tabs: Array<{ id: AppState['activeTab']; labelAr: string; labelEn: string; icon: React.ReactNode }> = [
    { id: 'lessons', labelAr: 'الدروس التفاعلية', labelEn: 'Lessons', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'playground', labelAr: 'المختبر الحر', labelEn: 'Python Sandbox', icon: <Terminal className="w-4 h-4" /> },
    { id: 'courses', labelAr: 'مكتبة مواد IT', labelEn: 'Course Library', icon: <Library className="w-4 h-4" /> },
    { id: 'glossary', labelAr: 'المصطلحات التقنية', labelEn: 'Tech Glossary', icon: <BookMarked className="w-4 h-4" /> },
    { id: 'visualizer', labelAr: 'محاكي الخوارزميات', labelEn: 'Algo Visualizer', icon: <Workflow className="w-4 h-4" /> },
    { id: 'ai', labelAr: 'مساعد الذكاء الاصطناعي', labelEn: 'AI Tutor', icon: <BrainCircuit className="w-4 h-4" /> },
    { id: 'quiz', labelAr: 'اختبارات بلا حدود', labelEn: 'Unlimited Quizzes', icon: <ListChecks className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top brand & controls bar */}
        <div className="flex items-center justify-between py-3 gap-4">
          {/* Logo & Platform Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  {state.lang === 'en' ? 'IT Education' : 'تعليم IT · منصة بايثون'}
                </h1>
                <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/60">
                  v2.6 Pro
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                {state.lang === 'en' 
                  ? 'Interactive Python & Comprehensive IT Academic Library' 
                  : 'المنصة التفاعلية لتعلم بايثون ومكتبة مواد تكنولوجيا المعلومات'}
              </p>
            </div>
          </div>

          {/* Right controls: Progress pill, certificate, language, theme */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Certificate Quick Button */}
            <button
              onClick={onOpenCertificate}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all border ${
                completedCount === totalLessons
                  ? 'bg-emerald-500 text-white border-emerald-600 hover:bg-emerald-600 shadow-sm'
                  : 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800 hover:bg-amber-100'
              }`}
              title={state.lang === 'en' ? 'View Certificate of Completion' : 'شهادة إتمام الأساسيات'}
            >
              <Award className="w-3.5 h-3.5" />
              <span className="hidden md:inline">
                {completedCount === totalLessons 
                  ? (state.lang === 'en' ? 'Claim Certificate!' : 'استلم شهادتك!') 
                  : (state.lang === 'en' ? 'Certificate' : 'الشهادة')}
              </span>
              <span className="font-mono text-[11px] font-bold">
                {completedCount}/{totalLessons}
              </span>
            </button>

            {/* Language Selector Segments */}
            <div className="flex items-center p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium">
              <button
                onClick={() => onLanguageChange('ar')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  state.lang === 'ar'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="العربية"
              >
                عربي
              </button>
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-2 py-1 rounded-md transition-colors ${
                  state.lang === 'en'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="English"
              >
                EN
              </button>
              <button
                onClick={() => onLanguageChange('both')}
                className={`px-2 py-1 rounded-md transition-colors hidden sm:block ${
                  state.lang === 'both'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 font-bold shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="ثنائي اللغة (Bilingual)"
              >
                AR+EN
              </button>
            </div>

            {/* Dark / Light Toggle */}
            <button
              onClick={onThemeToggle}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors"
              aria-label="Toggle theme"
            >
              {state.theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none border-t border-slate-100 dark:border-slate-800/80">
          {tabs.map((tab) => {
            const isActive = state.activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg whitespace-nowrap transition-all border ${
                  isActive
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-500/20'
                    : 'text-slate-600 dark:text-slate-300 border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {tab.icon}
                <span>{isEn ? tab.labelEn : tab.labelAr}</span>
                {tab.id === 'lessons' && completedCount > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-blue-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}>
                    {progressPercent}%
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Global Progress Bar Strip */}
      <div className="w-full h-1 bg-slate-100 dark:bg-slate-800">
        <div 
          className="h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 transition-all duration-500 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </header>
  );
};
