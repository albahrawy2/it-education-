import React, { useState } from 'react';
import { 
  Award, 
  X, 
  Printer, 
  CheckCircle2, 
  Sparkles, 
  ShieldCheck, 
  Download,
  Calendar,
  UserCheck
} from 'lucide-react';
import { AppState } from '../types';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  totalLessons: number;
  completedCount: number;
  onUpdateName: (name: string) => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  state,
  totalLessons,
  completedCount,
  onUpdateName,
}) => {
  if (!isOpen) return null;

  const isEn = state.lang === 'en';
  const isComplete = completedCount === totalLessons;
  const [name, setName] = useState(state.studentName || 'Mohamed Emad Ali Hassan');

  const handlePrint = () => {
    window.print();
  };

  const today = new Date().toLocaleDateString(isEn ? 'en-US' : 'ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-3xl w-full p-6 sm:p-8 space-y-6 relative print:shadow-none print:border-none print:w-full print:max-w-none">
        {/* Close button (hidden in print) */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 rtl:left-5 ltr:right-5 rtl:right-auto p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white print:hidden transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header (hidden in print) */}
        <div className="print:hidden space-y-3">
          <div className="flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-500" />
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              {isEn ? 'Certificate of Completion' : 'شهادة إتمام الأساسيات البرمجية'}
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-slate-500">
            {isComplete
              ? (isEn ? 'Congratulations! You have solved all coding challenges and completed the track.' : 'تهانينا! لقد أتممت جميع الدروس والتحديات البرمجية بنجاح واكتسبت الأساسيات الصلبة.')
              : (isEn ? `You completed ${completedCount} of ${totalLessons} lessons. Finish all lessons to verify your certificate!` : `لقد أتممت ${completedCount} من ${totalLessons} دروس. أكمل جميع الدروس لتوثيق الشهادة بالكامل.`)}
          </p>

          {/* Student name input */}
          <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 shrink-0">
              {isEn ? 'Student Full Name:' : 'اسم الطالب على الشهادة:'}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                onUpdateName(e.target.value);
              }}
              placeholder="اكتب اسمك الثلاثي هنا"
              className="w-full sm:max-w-xs text-xs sm:text-sm px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
            />
          </div>
        </div>

        {/* The Printable Certificate Design */}
        <div className="border-8 border-double border-amber-600/40 p-6 sm:p-10 rounded-2xl bg-gradient-to-br from-amber-50/20 via-white to-blue-50/20 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 text-center space-y-6 relative overflow-hidden shadow-inner">
          {/* Watermark seal */}
          <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
            <Award className="w-80 h-80 text-blue-900" />
          </div>

          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700 text-xs font-bold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" />
              <span>IT Education Academic Honors</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              {isEn ? 'CERTIFICATE OF ACHIEVEMENT' : 'شهادة إتمام وتفوق برمجي'}
            </h2>
            <p className="text-xs text-slate-500 font-mono tracking-widest uppercase">
              Python 3 Essentials & IT Foundations
            </p>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {isEn ? 'This is proudly presented to:' : 'تُمنح هذه الشهادة بكل فخر واعتزاز إلى الطالب:'}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-blue-700 dark:text-blue-400 font-serif border-b-2 border-slate-300 dark:border-slate-700 pb-2 max-w-md mx-auto">
              {name || (isEn ? 'Student Name' : 'اسم الطالب')}
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 max-w-lg mx-auto leading-relaxed">
            {isEn
              ? 'For demonstrated proficiency in foundational Computer Science and Python programming: variables, data types, control flow, loops, functions, lists, and problem-solving methodologies.'
              : 'لاجتيازه بنجاح وتفوق المنهج التأسيسي لعلوم الحاسوب ولغة بايثون: المتغيرات، أنواع البيانات، الجمل الشرطية، الحلقات، الدوال، القوائم، وخوارزميات حل المشكلات.'}
          </p>

          {/* Certificate metadata & seal */}
          <div className="grid grid-cols-3 items-center pt-6 border-t border-slate-200 dark:border-slate-800 text-xs">
            <div className="text-right rtl:text-right ltr:text-left space-y-1">
              <span className="text-slate-400 text-[10px] block">{isEn ? 'Date of Issue:' : 'تاريخ الإصدار:'}</span>
              <span className="font-bold font-mono text-slate-700 dark:text-slate-300">{today}</span>
            </div>

            <div className="flex flex-col items-center justify-center">
              <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-white shadow-lg border-2 border-white ring-4 ring-amber-500/20">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 mt-1 uppercase tracking-wider">
                VERIFIED
              </span>
            </div>

            <div className="text-left rtl:text-left ltr:text-right space-y-1">
              <span className="text-slate-400 text-[10px] block">{isEn ? 'Instructor / Director:' : 'المشرف الأكاديمي:'}</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 block">Mohamed Emad Ali Hassan</span>
              <span className="text-[10px] text-slate-400 font-mono">IT Education · © 2026</span>
            </div>
          </div>
        </div>

        {/* Actions bar (hidden in print) */}
        <div className="flex items-center justify-between pt-2 print:hidden">
          <div className="text-xs text-slate-500 font-mono">
            ID: IT-EDU-2026-{Math.abs(name.split('').reduce((acc, c) => acc + c.charCodeAt(0), 1000))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{isEn ? 'Print / Save PDF' : 'طباعة / حفظ الشهادة PDF'}</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {isEn ? 'Close' : 'إغلاق'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
