import React, { useState } from 'react';
import { 
  Search, 
  ExternalLink, 
  PlaySquare, 
  BookOpen, 
  Clock, 
  Sparkles, 
  Filter,
  CheckCircle2,
  FolderOpen
} from 'lucide-react';
import { ITCourse, AppState } from '../types';

interface CoursesViewProps {
  courses: ITCourse[];
  state: AppState;
}

export const CoursesView: React.FC<CoursesViewProps> = ({ courses, state }) => {
  const isEn = state.lang === 'en';
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [activeCourse, setActiveCourse] = useState<ITCourse | null>(null);

  const categories = [
    { id: 'all', labelAr: 'جميع المواد (14)', labelEn: 'All Courses (14)' },
    { id: 'programming', labelAr: 'البرمجة وهندسة البرمجيات', labelEn: 'Programming & SE' },
    { id: 'networks', labelAr: 'الشبكات والاتصالات', labelEn: 'Networks & Comms' },
    { id: 'security', labelAr: 'الأمن السيبراني والتشفير', labelEn: 'Cybersecurity' },
    { id: 'systems', labelAr: 'النظم والعتاد ولينكس', labelEn: 'Systems & OS' },
    { id: 'skills', labelAr: 'المهارات التقنية', labelEn: 'Skills & English' },
  ];

  const filteredCourses = courses.filter((c) => {
    const matchCat = selectedCat === 'all' || 
      (selectedCat === 'programming' && (c.category === 'programming' || c.category === 'data')) ||
      (selectedCat === 'networks' && c.category === 'networks') ||
      (selectedCat === 'security' && c.category === 'security') ||
      (selectedCat === 'systems' && (c.category === 'systems' || c.category === 'hardware')) ||
      (selectedCat === 'skills' && c.category === 'skills');

    const q = search.toLowerCase().trim();
    if (!q) return matchCat;

    const matchText = 
      c.title.ar.toLowerCase().includes(q) ||
      c.title.en.toLowerCase().includes(q) ||
      c.description.ar.toLowerCase().includes(q) ||
      c.description.en.toLowerCase().includes(q) ||
      c.keyTopics.some(t => t.ar.toLowerCase().includes(q) || t.en.toLowerCase().includes(q));

    return matchCat && matchText;
  });

  const getLevelBadge = (level: ITCourse['level']) => {
    switch (level) {
      case 'beginner':
        return {
          ar: 'مستوى تأسيسي للمبتدئين',
          en: 'Beginner Level',
          color: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
        };
      case 'intermediate':
        return {
          ar: 'مستوى متوسط',
          en: 'Intermediate Level',
          color: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
        };
      case 'advanced':
        return {
          ar: 'مستوى متقدم',
          en: 'Advanced Level',
          color: 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800'
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-blue-800/40">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-cyan-300 border border-cyan-400/30 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isEn ? 'Official ICT Curriculum Roadmap' : 'خارطة طريق مواد قسم تكنولوجيا المعلومات'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            {isEn ? 'Comprehensive IT Course Library' : 'مكتبة مقررات قسم IT الشاملة'}
          </h2>
          <p className="text-sm sm:text-base text-blue-100/90 leading-relaxed">
            {isEn
              ? 'Curated subjects based on the ICT Orientation lecture with verified high-yield Arabic YouTube playlists and resource hubs to deepen your understanding.'
              : 'مقررات معتمدة مستخلصة من محاضرة التوجيه لطلاب ICT، مع روابط قوائم تشغيل يوتيوب عربية موثوقة ومختارة بعناية لتعميق خبرتك الأكاديمية والعملية.'}
          </p>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 rtl:right-3.5 ltr:left-3.5 ltr:right-auto" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isEn ? "Search by course title, topic, or keyword..." : "ابحث باسم المادة، الموضوع، أو الكلمة المفتاحية (مثل بايثون، شبكات، SQL)..."}
              className="w-full bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-xs sm:text-sm py-2.5 px-10 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-hidden focus:border-blue-500 transition-colors"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-3 ltr:right-3 ltr:left-auto"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                selectedCat === cat.id
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-transparent hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {isEn ? cat.labelEn : cat.labelAr}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredCourses.map((course) => {
          const badge = getLevelBadge(course.level);
          return (
            <div
              key={course.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:shadow-md hover:border-blue-300 dark:hover:border-blue-700/60 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-3">
                {/* Top metadata tags */}
                <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                  <span className={`px-2.5 py-0.5 rounded-full border text-[11px] font-semibold ${badge.color}`}>
                    {isEn ? badge.en : badge.ar}
                  </span>
                  {course.hoursEst && (
                    <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>~{course.hoursEst} {isEn ? 'hrs' : 'ساعة'}</span>
                    </span>
                  )}
                </div>

                {/* Course Title */}
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {isEn ? course.title.en : course.title.ar}
                  </h3>
                  {state.lang === 'both' && (
                    <div className="text-xs text-slate-500 font-sans" dir="ltr">
                      {course.title.en}
                    </div>
                  )}
                </div>

                {/* Description */}
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {isEn ? course.description.en : course.description.ar}
                </p>

                {/* Key Topics List */}
                <div className="pt-2 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    {isEn ? 'Core Syllabus Modules:' : 'أبرز محاور المنهج:'}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {course.keyTopics.map((topic, tIdx) => (
                      <div 
                        key={tIdx} 
                        className="flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-1.5 rounded-lg border border-slate-100 dark:border-slate-800"
                      >
                        <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0" />
                        <span className="truncate">{isEn ? topic.en : topic.ar}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-400 font-medium">
                  {isEn ? course.badgeText.en : course.badgeText.ar}
                </span>

                <a
                  href={course.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs shadow-xs hover:shadow-md transition-all active:scale-95"
                >
                  <PlaySquare className="w-3.5 h-3.5" />
                  <span>{isEn ? 'Watch on YouTube' : 'فتح الدورة على YouTube'}</span>
                  <ExternalLink className="w-3 h-3 opacity-80" />
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCourses.length === 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500 space-y-3">
          <BookOpen className="w-10 h-10 mx-auto text-slate-400 opacity-50" />
          <h4 className="text-base font-bold text-slate-700 dark:text-slate-300">
            {isEn ? 'No courses match your search criteria' : 'لم يتم العثور على مقررات تطابق بحثك'}
          </h4>
          <p className="text-xs">
            {isEn ? 'Try another search keyword or clear filters.' : 'جرب البحث بكلمة مفتاحية أخرى أو إلغاء تصفية التصنيف.'}
          </p>
        </div>
      )}
    </div>
  );
};
