import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ChevronRight, 
  Workflow, 
  Sliders, 
  CheckCircle, 
  Sparkles,
  ArrowRight,
  Database
} from 'lucide-react';
import { AppState } from '../types';

interface AlgorithmVisualizerProps {
  state: AppState;
}

export const AlgorithmVisualizer: React.FC<AlgorithmVisualizerProps> = ({ state }) => {
  const isEn = state.lang === 'en';
  const [activeDemo, setActiveDemo] = useState<'loop' | 'condition' | 'max'>('loop');

  // Loop demo state
  const [nLimit, setNLimit] = useState(6);
  const [loopStep, setLoopStep] = useState(0); // 0 to nLimit
  const [loopPlaying, setLoopPlaying] = useState(false);

  // Condition demo state
  const [grade, setGrade] = useState(78);

  // Find max demo state
  const arrayData = [14, 42, 8, 95, 33, 76, 21];
  const [maxIdx, setMaxIdx] = useState(0);
  const [currentMax, setCurrentMax] = useState(arrayData[0]);

  // Loop auto play effect
  useEffect(() => {
    let timer: any;
    if (loopPlaying) {
      timer = setInterval(() => {
        setLoopStep((prev) => {
          if (prev >= nLimit) {
            setLoopPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 700);
    }
    return () => clearInterval(timer);
  }, [loopPlaying, nLimit]);

  // Compute loop total
  const computeLoopTotal = (step: number) => {
    let sum = 0;
    for (let i = 1; i <= step; i++) sum += i;
    return sum;
  };

  // Condition branch determination
  const getBranch = (g: number) => {
    if (g >= 90) return { id: 1, labelAr: 'ممتاز (A)', labelEn: 'Excellent (A)', color: 'text-emerald-500' };
    if (g >= 80) return { id: 2, labelAr: 'جيد جدًا (B)', labelEn: 'Very Good (B)', color: 'text-blue-500' };
    if (g >= 65) return { id: 3, labelAr: 'جيد (C)', labelEn: 'Good (C)', color: 'text-cyan-500' };
    if (g >= 50) return { id: 4, labelAr: 'مقبول (D)', labelEn: 'Pass (D)', color: 'text-amber-500' };
    return { id: 5, labelAr: 'راسب (F)', labelEn: 'Fail (F)', color: 'text-rose-500' };
  };

  // Find Max step
  const handleNextMaxStep = () => {
    if (maxIdx < arrayData.length - 1) {
      const nextIdx = maxIdx + 1;
      const nextVal = arrayData[nextIdx];
      setMaxIdx(nextIdx);
      if (nextVal > currentMax) {
        setCurrentMax(nextVal);
      }
    }
  };

  const handleResetMax = () => {
    setMaxIdx(0);
    setCurrentMax(arrayData[0]);
  };

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Workflow className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                {isEn ? 'Algorithm & Logic Flow Visualizer' : 'محاكي الخوارزميات وتدفق المنطق البرمجي'}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isEn 
                ? 'Visualize how loops, conditions, and memory pointers execute step by step inside computer memory.' 
                : 'شاهد خطوة بخطوة كيف تتغير المتغيرات وتتحرك الحلقات وتتفرع الشروط بداخل الذاكرة أثناء التنفيذ.'}
            </p>
          </div>

          {/* Demos Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveDemo('loop')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeDemo === 'loop'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {isEn ? '1. Loop Tracer' : '1. متتبع الحلقات'}
            </button>
            <button
              onClick={() => setActiveDemo('condition')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeDemo === 'condition'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {isEn ? '2. Decision Tree' : '2. شجرة القرارات'}
            </button>
            <button
              onClick={() => setActiveDemo('max')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                activeDemo === 'max'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {isEn ? '3. Array Scanner' : '3. فحص المصفوفات'}
            </button>
          </div>
        </div>
      </div>

      {/* Demo 1: Loop Visualizer */}
      {activeDemo === 'loop' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Controls & Variables View */}
          <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {isEn ? 'Loop Trace: Sum 1 to N' : 'تتبع حلقة الجمع: مجموع الأعداد من 1 إلى N'}
              </h3>
              <span className="text-xs font-mono text-blue-600 dark:text-blue-400 font-bold">
                {isEn ? `Step ${loopStep} of ${nLimit}` : `الخطوة ${loopStep} من ${nLimit}`}
              </span>
            </div>

            {/* Slider to change N */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span>{isEn ? 'Maximum Count (N):' : 'الحد الأقصى للتكرار (N):'}</span>
                <span className="font-mono font-bold text-blue-600">{nLimit}</span>
              </div>
              <input
                type="range"
                min={3}
                max={12}
                value={nLimit}
                onChange={(e) => {
                  setNLimit(Number(e.target.value));
                  setLoopStep(0);
                  setLoopPlaying(false);
                }}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            {/* Memory Registers Box */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center space-y-1">
                <span className="text-xs text-slate-400 font-mono font-bold uppercase">
                  {isEn ? 'Loop Counter (i)' : 'عداد الحلقة (i)'}
                </span>
                <div className="text-3xl font-black font-mono text-blue-600 dark:text-blue-400">
                  {loopStep}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center space-y-1">
                <span className="text-xs text-emerald-600 dark:text-emerald-400 font-mono font-bold uppercase">
                  {isEn ? 'Accumulator (total)' : 'المجموع التراكمي (total)'}
                </span>
                <div className="text-3xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                  {computeLoopTotal(loopStep)}
                </div>
              </div>
            </div>

            {/* Visual Accumulation Steps */}
            <div className="space-y-2">
              <span className="text-xs text-slate-400 font-medium">
                {isEn ? 'Iterations Visual Progress:' : 'تمثيل الخطوات المتتالية:'}
              </span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {Array.from({ length: nLimit }, (_, idx) => {
                  const stepNum = idx + 1;
                  const isDone = stepNum <= loopStep;
                  const isCurrent = stepNum === loopStep;
                  return (
                    <div
                      key={stepNum}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-xs transition-all ${
                        isCurrent
                          ? 'bg-blue-600 text-white ring-4 ring-blue-500/20 scale-105'
                          : isDone
                          ? 'bg-emerald-500 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400 border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {stepNum}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Stepper Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setLoopPlaying(!loopPlaying)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all"
              >
                {loopPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                <span>{loopPlaying ? (isEn ? 'Pause' : 'إيقاف مؤقت') : (isEn ? 'Auto Play' : 'تشغيل تلقائي')}</span>
              </button>

              <button
                onClick={() => {
                  if (loopStep < nLimit) setLoopStep(loopStep + 1);
                }}
                disabled={loopStep >= nLimit}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 transition-colors"
              >
                <span>{isEn ? 'Next Step' : 'الخطوة التالية'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => {
                  setLoopStep(0);
                  setLoopPlaying(false);
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors"
                title="إعادة التعيين"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Code Execution Sync Panel */}
          <div className="lg:col-span-6 bg-slate-950 rounded-2xl border border-slate-800 p-5 font-mono text-xs shadow-xl text-slate-200 space-y-3">
            <div className="flex items-center justify-between text-slate-400 pb-2 border-b border-slate-800">
              <span>logic_trace.py</span>
              <span className="text-cyan-400">Memory Watcher</span>
            </div>

            <pre className="space-y-1.5 p-3 rounded-xl bg-slate-900 border border-slate-800/80 leading-relaxed overflow-x-auto" dir="ltr">
              <div className="text-slate-500"># 1. تهيئة المتغيرات</div>
              <div className={loopStep === 0 ? 'bg-blue-600/30 text-blue-300 px-2 py-0.5 rounded border border-blue-500/40' : ''}>
                total = 0
              </div>
              <div className="text-slate-500 pt-2"># 2. حلقة التكرار</div>
              <div className={loopStep > 0 && loopStep <= nLimit ? 'bg-amber-600/30 text-amber-300 px-2 py-0.5 rounded border border-amber-500/40' : ''}>
                for i in range(1, {nLimit + 1}):
              </div>
              <div className={`pl-4 ${loopStep > 0 && loopStep <= nLimit ? 'bg-emerald-600/30 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40 font-bold' : ''}`}>
                total += i  <span className="text-slate-400 text-[10px]"># ({computeLoopTotal(Math.max(0, loopStep - 1))} + {loopStep} = {computeLoopTotal(loopStep)})</span>
              </div>
              <div className="text-slate-500 pt-2"># 3. طباعة النتيجة</div>
              <div className={loopStep >= nLimit ? 'bg-cyan-600/30 text-cyan-300 px-2 py-0.5 rounded border border-cyan-500/40' : ''}>
                print("الناتج النهائي:", total)
              </div>
            </pre>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-300 space-y-1">
              <div className="text-[11px] font-bold text-slate-400">
                {isEn ? 'Explanation of this step:' : 'شرح ما يحدث في هذه اللحظة:'}
              </div>
              <p className="text-xs leading-relaxed text-slate-300">
                {loopStep === 0
                  ? (isEn ? 'Initial state: total is 0, loop has not started yet.' : 'الحالة الابتدائية: المتغير total قيمته صفر، والحلقة لم تبدأ بعد.')
                  : loopStep < nLimit
                  ? (isEn ? `Iteration ${loopStep}: Counter i = ${loopStep}, adding to total gives ${computeLoopTotal(loopStep)}.` : `الدورة رقم ${loopStep}: قيمة i أصبحت ${loopStep}، تمت إضافتها للمجموع ليصبح ${computeLoopTotal(loopStep)}.`)
                  : (isEn ? `Finished all ${nLimit} iterations! Final total is ${computeLoopTotal(nLimit)}.` : `انتهت جميع التكرارات الـ ${nLimit}! الناتج النهائي هو ${computeLoopTotal(nLimit)}.`)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Demo 2: Condition Decision Tree */}
      {activeDemo === 'condition' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base sm:text-lg">
                {isEn ? 'Conditional Decision Tree: Grade Evaluator' : 'شجرة القرارات الشرطية: تقييم تقديرات الطلاب'}
              </h3>
              <p className="text-xs text-slate-500">
                {isEn ? 'Change the grade slider to see which condition branch triggers!' : 'حرّك شريط الدرجة وشاهد كيف يختار المفسر المسار المطابق فوراً!'}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400 font-bold">{isEn ? 'Grade:' : 'الدرجة:'}</span>
              <span className="text-2xl font-black font-mono text-blue-600 px-3 py-1 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800">
                {grade}%
              </span>
            </div>
          </div>

          <div className="space-y-2 max-w-md">
            <input
              type="range"
              min={0}
              max={100}
              value={grade}
              onChange={(e) => setGrade(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>

          {/* Condition Branches List */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {[
              { id: 1, cond: 'grade >= 90', labelAr: 'ممتاز (Excellent)', labelEn: 'Excellent', color: 'emerald' },
              { id: 2, cond: 'grade >= 80', labelAr: 'جيد جدًا (Very Good)', labelEn: 'Very Good', color: 'blue' },
              { id: 3, cond: 'grade >= 65', labelAr: 'جيد (Good)', labelEn: 'Good', color: 'cyan' },
              { id: 4, cond: 'grade >= 50', labelAr: 'مقبول (Pass)', labelEn: 'Pass', color: 'amber' },
              { id: 5, cond: 'else', labelAr: 'راسب (Fail)', labelEn: 'Fail', color: 'rose' },
            ].map((branch) => {
              const active = getBranch(grade).id === branch.id;
              return (
                <div
                  key={branch.id}
                  className={`p-4 rounded-xl border transition-all text-center space-y-2 ${
                    active
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/25 scale-105'
                      : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 opacity-60'
                  }`}
                >
                  <div className="font-mono text-xs font-bold" dir="ltr">{branch.cond}</div>
                  <div className="text-xs font-bold">{isEn ? branch.labelEn : branch.labelAr}</div>
                  {active && (
                    <div className="text-[11px] font-bold bg-white/20 px-2 py-0.5 rounded-full inline-block">
                      {isEn ? 'Active Branch ✓' : 'المسار المنفذ ✓'}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Demo 3: Array Max Scanner */}
      {activeDemo === 'max' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {isEn ? 'Algorithm: Find Largest Element in Array' : 'خوارزمية البحث عن العنصر الأكبر في المصفوفة'}
              </h3>
              <p className="text-xs text-slate-500">
                {isEn ? 'Step through the array to watch the comparison and max update.' : 'مر على عناصر المصفوفة لمشاهدة المقارنة وتحديث القيمة العظمى.'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">{isEn ? 'Current Max:' : 'الأكبر حالياً:'}</span>
              <span className="text-xl font-black font-mono text-emerald-600 px-3 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800">
                {currentMax}
              </span>
            </div>
          </div>

          {/* Array elements visual blocks */}
          <div className="flex items-center gap-3 overflow-x-auto py-3">
            {arrayData.map((val, idx) => {
              const isInspected = idx === maxIdx;
              const isMaxSoFar = val === currentMax;
              return (
                <div
                  key={idx}
                  className={`flex flex-col items-center justify-center p-4 min-w-[70px] rounded-2xl border transition-all ${
                    isInspected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md ring-4 ring-blue-500/20 scale-105'
                      : isMaxSoFar
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-400 font-bold'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-mono opacity-60">[{idx}]</span>
                  <span className="text-2xl font-black font-mono my-1">{val}</span>
                  {isInspected && (
                    <span className="text-[9px] bg-white/20 px-1.5 py-0.5 rounded-full font-bold">
                      {isEn ? 'Checking' : 'فحص'}
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleNextMaxStep}
              disabled={maxIdx >= arrayData.length - 1}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md disabled:opacity-40 transition-all cursor-pointer"
            >
              <span>{isEn ? 'Inspect Next Element' : 'فحص العنصر التالي'}</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </button>
            <button
              onClick={handleResetMax}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors"
              title="إعادة التعيين"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
