import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  Download, 
  Copy, 
  Check, 
  Trash2, 
  Code2, 
  Clock, 
  Terminal, 
  Sparkles,
  Layers,
  FileCode
} from 'lucide-react';
import { AppState, RunResult } from '../types';
import { executePython } from '../services/pythonRunner';

interface PlaygroundViewProps {
  state: AppState;
}

const TEMPLATES = [
  {
    id: 'gpa',
    nameAr: 'حساب المعدل التراكمي (GPA)',
    nameEn: 'GPA Calculator',
    code: `# برنامج حساب المعدل التراكمي للدرجات
grades = [92, 85, 78, 96, 88]
total = sum(grades)
average = total / len(grades)

print(f"عدد المواد: {len(grades)}")
print(f"مجموع الدرجات: {total}")
print(f"المعدل العام: {average:.2f}%")

if average >= 90:
    print("التقدير: ممتاز (Excellent) 🌟")
elif average >= 80:
    print("التقدير: جيد جدًا (Very Good) 👏")
elif average >= 70:
    print("التقدير: جيد (Good)")
else:
    print("التقدير: مقبول (Pass)")
`
  },
  {
    id: 'prime',
    nameAr: 'فحص الأعداد الأولية (Prime Checker)',
    nameEn: 'Prime Number Checker',
    code: `# خوارزمية فحص العدد الأولي
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

test_numbers = [2, 3, 4, 7, 10, 13, 17, 20, 29]
print("فحص الأعداد الأولية في القائمة:")
for num in test_numbers:
    status = "أولي (Prime)" if is_prime(num) else "غير أولي (Composite)"
    print(f"العدد {num:2d} -> {status}")
`
  },
  {
    id: 'bubble-sort',
    nameAr: 'خوارزمية فرز الفقاعات (Bubble Sort)',
    nameEn: 'Bubble Sort Algorithm',
    code: `# خوارزمية ترتيب العناصر (Bubble Sort)
def bubble_sort(arr):
    n = len(arr)
    # تكرار للمرور على عناصر المصفوفة
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                # تبديل العناصر
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

numbers = [64, 34, 25, 12, 22, 11, 90]
print("المصفوفة قبل الترتيب:", numbers)
sorted_numbers = bubble_sort(numbers)
print("المصفوفة بعد الترتيب:", sorted_numbers)
`
  },
  {
    id: 'interactive-calc',
    nameAr: 'آلة حاسبة تفاعلية مع input()',
    nameEn: 'Interactive Calculator with input()',
    code: `# آلة حاسبة تفاعلية تقرأ من المدخلات
print("=== آلة حاسبة بايثون البسيطة ===")
# في حقل المدخلات بالأسفل، ضع رقمين مثل:
# 25
# 5
num1 = float(input())
num2 = float(input())

print(f"العدد الأول: {num1}")
print(f"العدد الثاني: {num2}")
print(f"الجمع (+): {num1 + num2}")
print(f"الطرح (-): {num1 - num2}")
print(f"الضرب (*): {num1 * num2}")
if num2 != 0:
    print(f"القسمة (/): {num1 / num2:.2f}")
else:
    print("لا يمكن القسمة على صفر!")
`
  },
  {
    id: 'text-analyzer',
    nameAr: 'محلل الكلمات وتكرار الحروف',
    nameEn: 'Text Word Frequency Analyzer',
    code: `# تحليل إحصائي للنصوص
text = "python is powerful and python is fun to learn"
words = text.split()
freq = {}

for w in words:
    freq[w] = freq.get(w, 0) + 1

print(f"النص الأصلي: '{text}'")
print(f"إجمالي عدد الكلمات: {len(words)}")
print("\\nتكرار كل كلمة:")
for word, count in freq.items():
    print(f"  • {word:10s} : {count} مرات")
`
  }
];

export const PlaygroundView: React.FC<PlaygroundViewProps> = ({ state }) => {
  const isEn = state.lang === 'en';
  const [code, setCode] = useState(TEMPLATES[0].code);
  const [input, setInput] = useState('');
  const [result, setResult] = useState<RunResult | null>(null);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const val = target.value;
      const newVal = val.substring(0, start) + '    ' + val.substring(end);
      setCode(newVal);
      setTimeout(() => {
        target.selectionStart = target.selectionEnd = start + 4;
      }, 0);
    }
  };

  const handleRun = async () => {
    setRunning(true);
    try {
      const res = await executePython(code, input);
      setResult(res);
    } catch (err: any) {
      setResult({ out: [], err: String(err) });
    } finally {
      setRunning(false);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'it_education_script.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClearOutput = () => {
    setResult(null);
  };

  const handleSelectTemplate = (tmplCode: string, isInputTmpl = false) => {
    setCode(tmplCode);
    setResult(null);
    if (isInputTmpl) {
      setInput('25\n5');
    } else {
      setInput('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Templates Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Terminal className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                {isEn ? 'Python 3 Interactive Sandbox' : 'المختبر البرمجي الحر لـ بايثون 3'}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isEn 
                ? 'Write, test, and execute full Python scripts with instant offline execution.' 
                : 'اكتب وشغّل أي كود بايثون تريده بحرية تامة مع دعم المدخلات التفاعلية وحماية الحلقات.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? (isEn ? 'Copied' : 'تم النسخ') : (isEn ? 'Copy' : 'نسخ')}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="تنزيل الكود كملف .py"
            >
              <Download className="w-3.5 h-3.5 text-indigo-500" />
              <span>{isEn ? 'Download .py' : 'تنزيل .py'}</span>
            </button>
          </div>
        </div>

        {/* Templates list */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-xs text-slate-400 font-semibold shrink-0 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{isEn ? 'Presets:' : 'قوالب جاهزة:'}</span>
          </span>
          {TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => handleSelectTemplate(tmpl.code, tmpl.id === 'interactive-calc')}
              className="px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 border border-slate-200/80 dark:border-slate-700/60 transition-colors"
            >
              {isEn ? tmpl.nameEn : tmpl.nameAr}
            </button>
          ))}
        </div>
      </div>

      {/* Editor & Console Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Code Input (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
          <div className="bg-slate-950/80 px-4 py-3 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-mono text-slate-300 font-semibold">main.py</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
              <span>UTF-8</span>
              <span>·</span>
              <span>Python 3.10</span>
            </div>
          </div>

          <div className="p-4 space-y-3">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              rows={14}
              dir="ltr"
              className="w-full bg-slate-950 font-mono text-xs sm:text-sm text-cyan-200 p-4 rounded-xl border border-slate-800 focus:outline-hidden focus:border-blue-500 transition-colors resize-y leading-relaxed"
              placeholder="# اكتب كود بايثون هنا..."
            />

            {/* Stdin Area */}
            <div className="space-y-1">
              <label className="text-[11px] text-slate-400 font-medium block">
                {isEn ? 'Standard Input (stdin for input() statements):' : 'مدخلات البرنامج القياسية (stdin - عند استدعاء input()):'}
              </label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                rows={2}
                dir="ltr"
                placeholder={isEn ? "One input per line" : "قيمة لكل سطر (إذا كان الكود يطلب مدخلات)"}
                className="w-full bg-slate-950 font-mono text-xs text-amber-300 p-2.5 rounded-lg border border-slate-800 focus:outline-hidden focus:border-amber-500 resize-none"
              />
            </div>

            {/* Run button */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={handleRun}
                disabled={running}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-800 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-500/25 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
              >
                <Play className={`w-4 h-4 fill-current ${running ? 'animate-spin' : ''}`} />
                <span>{running ? (isEn ? 'Running code...' : 'جارٍ تنفيذ الكود...') : (isEn ? 'Run Code' : 'تشغيل الكود')}</span>
              </button>

              <button
                onClick={() => { setCode('# اكتب كود بايثون جديد هنا\n'); setResult(null); }}
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isEn ? 'Clear Editor' : 'إفراغ المحرر'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Output Console (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden min-h-[350px] flex flex-col">
          <div className="bg-slate-900/90 px-4 py-3 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono text-slate-300 font-bold">
                {isEn ? 'Execution Console' : 'طرفية المخرجات والنتائج'}
              </span>
            </div>
            {result && (
              <button
                onClick={handleClearOutput}
                className="text-slate-400 hover:text-rose-400 p-1 rounded transition-colors"
                title="مسح المخرجات"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="p-4 flex-1 font-mono text-xs space-y-2 select-text overflow-y-auto max-h-[500px]">
            {result?.execTimeMs !== undefined && (
              <div className="flex items-center justify-between text-[11px] text-slate-500 pb-2 border-b border-slate-900">
                <span className="text-slate-400">Exit Code: {result.err ? 1 : 0}</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {result.execTimeMs}ms
                </span>
              </div>
            )}

            {result ? (
              <>
                {result.out.length > 0 && (
                  <div className="space-y-1 text-emerald-400 whitespace-pre-wrap leading-relaxed">
                    {result.out.map((line, idx) => (
                      <div key={idx} dir="ltr">{line}</div>
                    ))}
                  </div>
                )}
                {result.err && (
                  <div className="text-rose-400 bg-rose-950/50 p-3 rounded-lg border border-rose-900/70 whitespace-pre-wrap leading-relaxed" dir="ltr">
                    <div className="font-bold text-rose-300 mb-1">Traceback / Error:</div>
                    {result.err}
                  </div>
                )}
                {result.out.length === 0 && !result.err && (
                  <div className="text-slate-500 italic">
                    {isEn ? '(Process finished with exit code 0 - No output generated)' : '(انتهت العملية بنجاح - لم يتم إنتاج أي مخرجات نصية)'}
                  </div>
                )}
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-slate-600 py-12">
                <Code2 className="w-8 h-8 mb-2 opacity-40 text-slate-500" />
                <p className="text-xs">
                  {isEn 
                    ? 'Output will appear here when you run code.' 
                    : 'ستظهر نتائج تشغيل البرنامج ورسائل الخطأ هنا فور الضغط على زر التشغيل.'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
