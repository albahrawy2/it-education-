import React from 'react';
import { Terminal, Shield, Award, Heart } from 'lucide-react';
import { AppState } from '../types';

interface FooterProps {
  state: AppState;
  onTabChange: (tab: AppState['activeTab']) => void;
}

export const Footer: React.FC<FooterProps> = ({ state, onTabChange }) => {
  const isEn = state.lang === 'en';

  return (
    <footer className="mt-16 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-colors py-10 print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-sm">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                {isEn ? 'IT Education · Python Platform' : 'تعليم IT · المنصة التفاعلية'}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isEn 
                  ? 'Designed for Computer Science & IT students' 
                  : 'مخصصة لطلاب ومحبي تكنولوجيا المعلومات والبرمجة'}
              </p>
            </div>
          </div>

          {/* Quick links */}
          <div className="flex items-center gap-4 text-xs font-semibold text-slate-600 dark:text-slate-400 flex-wrap justify-center">
            <button 
              onClick={() => { onTabChange('lessons'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isEn ? 'Lessons' : 'الدروس'}
            </button>
            <span>·</span>
            <button 
              onClick={() => { onTabChange('playground'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isEn ? 'Sandbox' : 'المختبر الحر'}
            </button>
            <span>·</span>
            <button 
              onClick={() => { onTabChange('courses'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isEn ? 'Course Library' : 'مكتبة المواد'}
            </button>
            <span>·</span>
            <button 
              onClick={() => { onTabChange('glossary'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isEn ? 'Glossary' : 'المصطلحات'}
            </button>
            <span>·</span>
            <button 
              onClick={() => { onTabChange('visualizer'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              {isEn ? 'Visualizer' : 'محاكي المنطق'}
            </button>
          </div>

          {/* Security & Offline Badge */}
          <div className="flex items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
            <Shield className="w-3.5 h-3.5 text-emerald-500" />
            <span>LoopGuard Protected · Offline Ready</span>
          </div>
        </div>

        {/* Copyright strip */}
        <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-2">
          <div>
            © 2026 Mohamed Emad Ali Hassan. All rights reserved. IT Education / تعليم IT.
          </div>
          <div className="flex items-center gap-1 font-medium">
            <span>{isEn ? 'Built with precision for education' : 'طُوّر بأعلى دقة واحترافية للتعليم التقني'}</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-current ml-1" />
          </div>
        </div>
      </div>
    </footer>
  );
};
