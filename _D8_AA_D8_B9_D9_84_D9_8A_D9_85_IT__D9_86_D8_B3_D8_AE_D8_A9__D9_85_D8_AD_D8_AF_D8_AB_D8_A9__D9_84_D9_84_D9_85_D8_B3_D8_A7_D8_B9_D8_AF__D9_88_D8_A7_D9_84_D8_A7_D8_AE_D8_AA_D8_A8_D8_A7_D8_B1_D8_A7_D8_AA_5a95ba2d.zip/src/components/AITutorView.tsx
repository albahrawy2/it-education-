import React, { useEffect, useRef, useState } from 'react';
import { Bot, Send, Sparkles, User, Trash2, LoaderCircle, Wifi, WifiOff } from 'lucide-react';
import { AppState } from '../types';

type Message = { role: 'user' | 'assistant'; content: string };
const STORE = 'it_education_ai_chat_v1';
const suggestions = ['اشرحلي المتغيرات في Python بمثال بسيط', 'ما الفرق بين RAM و ROM؟', 'يعني إيه IP Address؟', 'اكتبلي كود Python يحسب المتوسط واشرحه'];

export const AITutorView: React.FC<{ state: AppState }> = ({ state }) => {
  const isEn = state.lang === 'en';
  const [messages, setMessages] = useState<Message[]>(() => {
    try { const saved = localStorage.getItem(STORE); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [connection, setConnection] = useState<'unknown' | 'online' | 'offline'>('unknown');
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { try { localStorage.setItem(STORE, JSON.stringify(messages.slice(-80))); } catch {} endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [messages]);

  async function send(text = input) {
    const prompt = text.trim(); if (!prompt || busy) return;
    const history = [...messages, { role: 'user' as const, content: prompt }];
    setMessages(history); setInput(''); setBusy(true);
    try {
      const response = await fetch('/api/ai-chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: prompt, history: history.slice(-12), language: isEn ? 'en' : 'ar' }) });
      if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.error || `HTTP ${response.status}`); }
      const data = await response.json();
      if (!data.reply) throw new Error('لم يصل رد من نموذج الذكاء الاصطناعي.');
      setConnection('online'); setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (error) {
      setConnection('offline');
      const detail = error instanceof Error ? error.message : 'تعذر الاتصال';
      setMessages(prev => [...prev, { role: 'assistant', content: isEn ? `I couldn't reach the AI service (${detail}). Check that the app server is running and GEMINI_API_KEY is configured in AI Studio Secrets. Your message is still saved locally.` : `مش قادر أوصل لخدمة الذكاء الاصطناعي دلوقتي (${detail}). اتأكد إن السيرفر شغال وإن GEMINI_API_KEY متضاف في Secrets داخل AI Studio. رسالتك محفوظة على الجهاز.` }]);
    } finally { setBusy(false); }
  }
  return <section className="flex flex-col min-h-[70dvh] h-[calc(100dvh-190px)] max-h-[1000px] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
    <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50">
      <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-blue-600 text-white grid place-items-center"><Bot size={22}/></div><div><h2 className="font-black text-slate-900 dark:text-white">{isEn ? 'IT AI Tutor' : 'مساعد تعليم IT الذكي'}</h2><p className="text-xs text-slate-500">{isEn ? 'Programming, IT concepts and debugging' : 'اسأل عن البرمجة والشبكات ومفاهيم IT وتصحيح الأكواد'}</p></div></div>
      <div className="flex items-center gap-2"><span className="text-xs text-slate-500 hidden sm:inline">{connection === 'online' ? (isEn ? 'Connected' : 'متصل') : connection === 'offline' ? (isEn ? 'Connection issue' : 'مشكلة اتصال') : (isEn ? 'Ready' : 'جاهز')}</span>{connection === 'online' ? <Wifi className="text-emerald-500" size={17}/> : <WifiOff className="text-slate-400" size={17}/>}<button onClick={() => setMessages([])} title={isEn ? 'Clear chat' : 'مسح المحادثة'} className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800"><Trash2 size={17}/></button></div>
    </div>
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.length === 0 && <div className="max-w-xl mx-auto py-8 text-center"><div className="mx-auto mb-4 w-14 h-14 rounded-2xl bg-violet-100 dark:bg-violet-950 text-violet-600 grid place-items-center"><Sparkles size={27}/></div><h3 className="text-xl font-black mb-2">{isEn ? 'What would you like to learn?' : 'حابب تتعلم إيه النهارده؟'}</h3><p className="text-sm text-slate-500 mb-5">{isEn ? 'Ask follow-up questions and request step-by-step explanations.' : 'اسأل براحتك، واطلب شرح خطوة بخطوة وأمثلة عملية.'}</p><div className="grid sm:grid-cols-2 gap-2 text-start">{suggestions.map(s => <button key={s} onClick={() => send(s)} className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-start hover:border-violet-400 hover:bg-violet-50 dark:hover:bg-violet-950/30">{s}</button>)}</div></div>}
      {messages.map((m, i) => <div key={i} className={`flex gap-2 ${m.role === 'user' ? 'justify-start' : 'justify-end'}`}><div className={`flex gap-2 max-w-[92%] sm:max-w-[82%] ${m.role === 'user' ? 'flex-row' : 'flex-row-reverse'}`}><div className={`shrink-0 w-8 h-8 rounded-lg grid place-items-center ${m.role === 'user' ? 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300' : 'bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300'}`}>{m.role === 'user' ? <User size={16}/> : <Bot size={16}/>}</div><div className={`rounded-2xl px-4 py-3 text-sm leading-7 whitespace-pre-wrap break-words ${m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-sm'}`}>{m.content}</div></div></div>)}
      {busy && <div className="flex items-center gap-2 text-sm text-slate-500"><LoaderCircle className="animate-spin" size={17}/>{isEn ? 'Thinking…' : 'المساعد بيفكر…'}</div>}<div ref={endRef}/>
    </div>
    <form onSubmit={e => { e.preventDefault(); void send(); }} className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 flex items-end gap-2 bg-white dark:bg-slate-900"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} rows={1} placeholder={isEn ? 'Ask anything about IT…' : 'اكتب سؤالك عن البرمجة أو IT هنا…'} className="min-h-12 max-h-36 flex-1 resize-y rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-4 py-3 text-sm outline-none focus:border-violet-500"/><button disabled={busy || !input.trim()} className="h-12 w-12 shrink-0 rounded-xl bg-violet-600 text-white grid place-items-center disabled:opacity-40 hover:bg-violet-700" aria-label={isEn ? 'Send' : 'إرسال'}><Send size={18}/></button></form>
  </section>;
};
