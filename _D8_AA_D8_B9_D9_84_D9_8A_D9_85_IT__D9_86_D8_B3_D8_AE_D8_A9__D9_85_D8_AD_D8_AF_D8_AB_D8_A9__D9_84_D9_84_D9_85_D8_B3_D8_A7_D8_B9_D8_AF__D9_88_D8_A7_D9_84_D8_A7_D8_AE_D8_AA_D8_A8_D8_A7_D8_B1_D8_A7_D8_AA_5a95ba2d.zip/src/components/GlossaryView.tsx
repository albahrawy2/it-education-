import React, { useState } from 'react';
import { 
  Search, 
  BookMarked, 
  Copy, 
  Check, 
  Lightbulb, 
  Filter,
  Layers,
  Sparkles
} from 'lucide-react';
import { GlossaryTerm, AppState } from '../types';

interface GlossaryViewProps {
  terms: GlossaryTerm[];
  state: AppState;
}

export const GlossaryView: React.FC<GlossaryViewProps> = ({ terms, state }) => {
  const isEn = state.lang === 'en';
  const isBoth = state.lang === 'both';
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', labelAr: 'جميع المصطلحات', labelEn: 'All Terms' },
    { id: 'programming', labelAr: 'البرمجة', labelEn: 'Programming' },
    { id: 'networks', labelAr: 'الشبكات والاتصالات', labelEn: 'Networking' },
    { id: 'security', labelAr: 'الأمن السيبراني', labelEn: 'Security' },
    { id: 'systems', labelAr: 'النظم والخوادم', labelEn: 'Systems' },
    { id: 'data', labelAr: 'قواعد البيانات', labelEn: 'Databases' },
    { id: 'hardware', labelAr: 'العتاد والمكونات', labelEn: 'Hardware' },
  ];

  const filteredTerms = terms.filter((t) => {
    const matchCat = selectedCat === 'all' || t.category === selectedCat;
    const q = search.toLowerCase().trim();
    if (!q) return matchCat;

    const matchText = 
      t.termEn.toLowerCase().includes(q) ||
      t.termAr.toLowerCase().includes(q) ||
      t.definition.ar.toLowerCase().includes(q) ||
      t.definition.en.toLowerCase().includes(q) ||
      (t.example && (t.example.ar.toLowerCase().includes(q) || t.example.en.toLowerCase().includes(q)));

    return matchCat && matchText;
  });

  const handleCopy = (t: GlossaryTerm) => {
    const text = `${t.termAr} (${t.termEn}): ${t.definition.ar} - ${t.definition.en}`;
    navigator.clipboard.writeText(text);
    setCopiedId(t.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <BookMarked className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                {isEn ? 'IT & Computer Science Technical Glossary' : 'قاموس مصطلحات تكنولوجيا المعلومات والبرمجة'}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isEn 
                ? 'Searchable bilingual dictionary containing essential engineering concepts, acronyms, and practical examples.' 
                : 'دليل شامل وثنائي اللغة للمصطلحات التقنية والاختصارات الهندسية الأكثر تداولاً في تكنولوجيا المعلومات.'}
            </p>
          </div>

          <div className="text-xs font-mono font-bold px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
            {filteredTerms.length} / {terms.length} {isEn ? 'Terms' : 'مصطلح تقني'}
          </div>
        </div>

        {/* Search bar */}
        <div className="mt-4 relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 rtl:right-3.5 ltr:left-3.5 ltr:right-auto" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={isEn ? "Search term in English or Arabic (e.g. Algorithm, DNS, Cache)..." : "ابحث عن أي مصطلح بالعربية أو الإنجليزية (مثل خوارزمية، جدار حماية، SQL)..."}
            className="w-full bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-xs sm:text-sm py-2.5 px-10 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-hidden focus:border-indigo-500 transition-colors"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 absolute left-3 top-1/2 -translate-y-1/2 rtl:left-3 ltr:right-3 ltr:left-auto"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter categories */}
        <div className="mt-4 flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                selectedCat === cat.id
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-transparent hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {isEn ? cat.labelEn : cat.labelAr}
            </button>
          ))}
        </div>
      </div>

      {/* Terms Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTerms.map((term) => (
          <div
            key={term.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs hover:border-indigo-300 dark:hover:border-indigo-700/60 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              {/* Top bar */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-mono font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                  {term.category}
                </span>

                <button
                  onClick={() => handleCopy(term)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
                  title="نسخ المصطلح والتعريف"
                >
                  {copiedId === term.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              {/* Title & Pronunciation */}
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                  {term.termAr}
                </h3>
                <div className="text-xs font-mono font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5" dir="ltr">
                  {term.termEn}
                </div>
              </div>

              {/* Definition */}
              <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed space-y-1">
                {!isEn && <p dir="rtl">{term.definition.ar}</p>}
                {(isEn || isBoth) && (
                  <p 
                    dir="ltr" 
                    className={isBoth ? 'text-xs text-slate-500 dark:text-slate-400 font-sans' : ''}
                  >
                    {term.definition.en}
                  </p>
                )}
              </div>

              {/* Example box if present */}
              {term.example && (
                <div className="p-3 rounded-xl bg-indigo-50/50 dark:bg-slate-800/60 border border-indigo-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-indigo-900 dark:text-indigo-300 mb-1">
                    <Lightbulb className="w-3.5 h-3.5 text-indigo-600" />
                    <span>{isEn ? 'Practical Example:' : 'مثال عملي تطبيقي:'}</span>
                  </div>
                  <div className="text-slate-700 dark:text-slate-300 font-mono text-[11px] leading-relaxed">
                    {isBoth ? `${term.example.ar} (${term.example.en})` : isEn ? term.example.en : term.example.ar}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredTerms.length === 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500">
          <p className="text-sm">
            {isEn ? 'No technical terms found matching your query.' : 'لم يتم العثور على مصطلحات تطابق بحثك.'}
          </p>
        </div>
      )}
    </div>
  );
};
