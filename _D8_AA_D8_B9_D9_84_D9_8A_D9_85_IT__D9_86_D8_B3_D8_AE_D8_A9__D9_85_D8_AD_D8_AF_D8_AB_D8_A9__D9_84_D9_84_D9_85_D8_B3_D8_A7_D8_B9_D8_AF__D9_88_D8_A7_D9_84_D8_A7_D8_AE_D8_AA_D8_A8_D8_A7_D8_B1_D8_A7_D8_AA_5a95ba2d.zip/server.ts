import express, { Request, Response } from 'express';
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '2mb' }));

  // Gemini calls stay on the server so the API key is never shipped to the browser.
  app.post('/api/ai-chat', async (req: Request, res: Response) => {
    try {
      const { message, history = [], language = 'ar' } = req.body ?? {};
      if (typeof message !== 'string' || !message.trim()) { res.status(400).json({ error: 'اكتب سؤالًا أولًا.' }); return; }
      if (!process.env.GEMINI_API_KEY) { res.status(503).json({ error: 'GEMINI_API_KEY is not configured in AI Studio Secrets.' }); return; }
      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const safeHistory = Array.isArray(history) ? history.slice(-10).filter((m: any) => m && ['user','assistant'].includes(m.role) && typeof m.content === 'string').map((m: any) => `${m.role === 'user' ? 'Student' : 'Tutor'}: ${m.content.slice(0, 5000)}`).join('\n') : '';
      const prompt = `You are a careful, friendly IT and programming tutor for a student. Answer in ${language === 'en' ? 'English' : 'Arabic Egyptian/clear Arabic'}. Explain step by step, use examples, format code clearly, point out uncertainty, and never claim code was executed unless it was. Keep answers practical.\nConversation:\n${safeHistory}\nStudent: ${message.slice(0, 8000)}\nTutor:`;
      const result = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
      const reply = result.text?.trim();
      if (!reply) { res.status(502).json({ error: 'Gemini returned an empty response.' }); return; }
      res.json({ reply });
    } catch (error) {
      console.error('AI chat failed:', error);
      res.status(502).json({ error: 'تعذر الحصول على إجابة من Gemini. حاول مرة أخرى.' });
    }
  });

  app.post('/api/generate-quiz', async (req: Request, res: Response) => {
    try {
      const { topic = 'Python', difficulty = 'متوسط', language = 'ar', count = 8 } = req.body ?? {};
      if (!process.env.GEMINI_API_KEY) { res.status(503).json({ error: 'GEMINI_API_KEY is not configured.' }); return; }
      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const n = Math.max(1, Math.min(100, Number(count) || 8));
      const prompt = `Generate ${n} distinct multiple-choice educational quiz questions about ${String(topic).slice(0,100)}. Difficulty: ${String(difficulty).slice(0,30)}. Language: ${language === 'en' ? 'English' : 'Arabic'}. Return ONLY valid JSON: {"questions":[{"q":"question","options":["A","B","C","D"],"answer":0,"explanation":"brief explanation"}]}. answer is a zero-based integer. Ensure exactly 4 options and one correct answer. Avoid trick ambiguity.`;
      const result = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: 'application/json' } });
      const raw = result.text || '';
      const parsed = JSON.parse(raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,''));
      const questions = Array.isArray(parsed.questions) ? parsed.questions.filter((q: any) => typeof q.q === 'string' && Array.isArray(q.options) && q.options.length === 4 && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < 4 && q.options.every((x: any) => typeof x === 'string')).slice(0,n) : [];
      if (!questions.length) { res.status(502).json({ error: 'No valid questions returned.' }); return; }
      res.json({ questions });
    } catch (error) {
      console.error('Quiz generation failed:', error);
      res.status(502).json({ error: 'تعذر توليد الأسئلة حاليًا.' });
    }
  });

  // Python runner API using the extracted offline runner logic
  app.post('/api/run-python', (req: Request, res: Response) => {
    const { code, input = '' } = req.body;

    if (typeof code !== 'string') {
      res.status(400).json({ out: [], err: 'Invalid code provided' });
      return;
    }

    // Runner Python script with LoopGuard and safe timeout execution
    const runnerScript = `
import sys, os, io, ast, contextlib, json

class LoopGuard(ast.NodeTransformer):
    def __init__(self):
        self.counter_name = "__it_loop_counter"

    def _guard(self, node):
        tick = ast.parse(
            f"{self.counter_name} += 1\\n"
            f"if {self.counter_name} > 150000:\\n"
            f"    raise TimeoutError('توقف التنفيذ: عدد تكرارات الحلقة كبير جدًا (حلقة غير منتهية؟)')"
        ).body
        node.body = tick + node.body
        return node

    def visit_For(self, node):
        self.generic_visit(node)
        return self._guard(node)

    def visit_While(self, node):
        self.generic_visit(node)
        return self._guard(node)

payload = json.loads(sys.stdin.read())
user_code = payload.get("code", "")
user_input = payload.get("input", "")

output = io.StringIO()
namespace = {"__name__": "__main__"}
old_stdin = sys.stdin

try:
    sys.stdin = io.StringIO(user_input)
    tree = ast.parse(user_code, filename="<code>", mode="exec")
    tree = LoopGuard().visit(tree)
    ast.fix_missing_locations(tree)
    namespace["__it_loop_counter"] = 0
    compiled = compile(tree, "<code>", "exec")
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
        exec(compiled, namespace, namespace)
    res = {"out": output.getvalue().rstrip("\\n").splitlines() if output.getvalue().rstrip("\\n") else [], "err": None}
    print(json.dumps(res, ensure_ascii=False))
except Exception as exc:
    msg = f"{type(exc).__name__}: {exc}"
    captured = output.getvalue().rstrip("\\n")
    res = {"out": captured.splitlines() if captured else [], "err": msg}
    print(json.dumps(res, ensure_ascii=False))
finally:
    sys.stdin = old_stdin
`;

    const py = spawn('python3', ['-c', runnerScript]);
    let stdoutData = '';
    let stderrData = '';
    let timedOut = false;

    const timer = setTimeout(() => {
      timedOut = true;
      py.kill('SIGKILL');
      res.json({
        out: [],
        err: 'توقف التنفيذ: استغرق الكود أكثر من 5 ثوانٍ (حلقة لا نهائية محتملة)'
      });
    }, 5000);

    py.stdout.on('data', (d) => {
      stdoutData += d.toString();
    });

    py.stderr.on('data', (d) => {
      stderrData += d.toString();
    });

    py.on('close', (exitCode) => {
      clearTimeout(timer);
      if (timedOut) return;

      try {
        const parsed = JSON.parse(stdoutData.trim());
        res.json(parsed);
      } catch (err) {
        if (stderrData) {
          res.json({ out: [], err: stderrData.trim() });
        } else {
          const lines = stdoutData.trim().split('\n').filter(Boolean);
          res.json({ out: lines, err: null });
        }
      }
    });

    // Send code and input cleanly as JSON
    py.stdin.write(JSON.stringify({ code, input }));
    py.stdin.end();
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
